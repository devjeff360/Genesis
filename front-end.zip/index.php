<?php

error_reporting(0);

    $user = $_GET['user'];
?>
<!DOCTYPE html>
<!--[if IE 8 ]><html class="ie" xmlns="http://www.w3.org/1999/xhtml" xml:lang="en-US" lang="en-US"> <![endif]-->
<!--[if (gte IE 9)|!(IE)]><!--><html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en-US" lang="en-US"><!--<![endif]-->

<head>
    <!-- Basic Page Needs -->
    <meta charset="utf-8">
    <!--[if IE]><meta http-equiv='X-UA-Compatible' content='IE=edge,chrome=1'><![endif]-->
    <title>Largest Crypto Cloud Mining || Genesis Mining</title>

    <meta name="author" content="themesflat.com">

    <!-- Mobile Specific Metas -->
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">

    <!-- Bootstrap  -->
    <link rel="stylesheet" type="text/css" href="stylesheets/bootstrap.css" >

    <!-- Theme Style -->
    <link rel="stylesheet" type="text/css" href="stylesheets/style.css">

    <!-- Responsive -->
    <link rel="stylesheet" type="text/css" href="stylesheets/responsive.css">

    <!-- Animation Style -->
    <link rel="stylesheet" type="text/css" href="stylesheets/animate.css">

    <!-- REVOLUTION LAYERS STYLES -->
    <link rel="stylesheet" type="text/css" href="revolution/css/layers.css">
    <link rel="stylesheet" type="text/css" href="revolution/css/settings.css">

    <!-- Favicon and touch icons  -->
    <link href="images/genfav.jpg" rel="shortcut icon">
    
    

     <style>
       
         
         /* ##### 10.0 Cool Fact Area CSS ##### */

.cool-facts-area {
    padding: 20px 0 10px;

}

.single_cool_fact {
    position: relative;
    z-index: 1;
    
    border: 1px solid #fff;
    border-bottom: 3px solid #fff;
    border-radius: 0 0 20px 20px;
    padding: 15px;
    overflow: hidden;
    margin-bottom: 15px;
}


.cool_fact_icon i {
    font-size: 100px;
    position: absolute;
    top: 50%;
    left: 50%;
    transform: translate(-50%, -50%);
    opacity: .1;
    color: #242020;
    font-weight: 800;
}

.cool_fact_detail h3 {
    font-size: 35px;
    font-weight: 600;
    margin-top: 0 !important;
    margin-top: 7px;
    color: #fff !important;
}

.cool_fact_detail h2 {
    font-size: 14px;
    margin-bottom: 0;
    color: #fff !important;
    text-transform: uppercase;
}
  
    .payment-logos img {
  width: 30px;
  margin-right: 5px;
}

.payment-logos img.last {
  margin-right: 0;
}
    </style>
   

    <!--[if lt IE 9]>
        <script src="javascript/html5shiv.js"></script>
        <script src="javascript/respond.min.js"></script>
    <![endif]-->
    
    <style>
        svg{
            width: 250px;
            height:125px;
        }
        
        
         @media only screen and (max-width: 767px) {
           
        }
         @media only screen and (min-width: 767px) {
        #rw{
                 margin-top: -100px;
                 margin-bottom: -100px;
             }
        }
    </style>
    
    <script src="//code.jivosite.com/widget/0MPNPGglUA" async></script>
</head> 
<body class="header_sticky">
   

    <!-- Boxed -->
    <div class="boxed">
        
        <div class="top">
            <div class="container">
                <div class="row">
                    <div class="col-md-4">
                        <div class="wrap-language-info clearfix">
                            <ul class="flat-info">
                               <p><?php echo $date = date("D, M d, Y"); ?></p>
                            </ul><!-- /.flat-info -->
                           <!-- /.flat-language -->
                        </div><!-- /.wrap-language-info -->
                    </div><!-- /.clo-md-6 -->
                    <div class="col-md-8">
                        <div class="wrap-social-sign pull-right clearfix">
                            <ul class="flat-social"><li>
                             <div id="ytWidget"></div><script src="https://translate.yandex.net/website-widget/v1/widget.js?widgetId=ytWidget&pageLang=en&widgetTheme=dark&autoMode=false" type="text/javascript"></script><!-- /.flat-social -->    
                                
                            </li></ul>
                           
                            <div class="flat-sign">
                                <a href="account/index.php">Sign in</a>
                                <a href="account/index.php" class="active">Sign Up</a>
                            </div><!-- /.flat-sign -->
                        </div><!-- /.wrap-social-sign -->
                    </div><!-- /.col-md-6 -->
                </div><!-- /.row -->
            </div><!-- /.container -->
        </div><!-- /.top -->

        <div class="flat-header-wrap">
            <div class="header header-top">
                <div class="container">
                    <div class="row">
                        <div class="col-md-12 col-lg-3">
                            <div id="logo" class="logo">
                                <a href="#" rel="home">
                                    <img src="images/logotop.png" alt="image">
                                </a>
                            </div><!-- /.logo -->
                        </div><!-- /.col-lg-3 -->
                        <div class="col-md-12 col-lg-9">
                            
                        </div><!-- /.col-lg-9 -->
                    </div><!-- /.row -->
                </div><!-- /.container -->
            </div><!-- /.header-top -->

            <header id="header" class="header header-classic">
                <div class="container">
                    <div class="row">
                        <div class="col-md-12">
                            <div class="nav-wrap">
                                <nav id="mainnav" class="mainnav">
                                    <ul class="menu">
                                        <li class="active">
                                            <a href="index.php?user=<?php echo $user; ?>">HOME</a>
                                        </li>
                                        <li >
                                            <a href="about.php?user=<?php echo $user; ?>">ABOUT US</a>
                                        </li>
                                        <li>
                                            <a href="how-it-works.php?user=<?php echo $user; ?>">HOW IT WORKS</a>
                                          
                                        </li>
                                        <li>
                                            <a href="plans.php?user=<?php echo $user; ?>">PLANS</a>
                                        </li>
                                        <li>
                                            <a href="testimony.php?user=<?php echo $user; ?>">TESTIMONY</a>
                                        </li>
                                        <li>
                                            <a href="contact.php?user=<?php echo $user; ?>">CONTACT US</a>
                                        </li>
                                    </ul>
                                </nav><!-- /.mainnav -->
                                <ul class="menu-extra">
                                    <li class="search">
                                        <a href="#"><i class="fa fa-search"></i></a>
                                    </li>
                                    <li class="quote">
                                        <a href="account/index.php" title="">Get Started </a>
                                    </li>
                                </ul><!-- /.menu-extra -->
                                <div class="top-search">            
                                    <form role="search" method="get" class="search-form" action="#">
                                        <label>                                    
                                            <input type="search" class="search-field" placeholder="Search …" value="" name="s">
                                        </label>
                                        <span class="fa fa-times close"></span>
                                    </form>       
                                </div><!-- /.top-serach -->
                                <div class="btn-menu">
                                    <span></span>
                                </div><!-- /.mobile menu button -->
                            </div><!-- /.nav-wrap -->
                        </div>
                    </div><!-- /.row -->
                </div><!-- /.container -->
            </header><!-- /header -->
        </div><!-- /.flat-header-wrap -->
        
        
        
       <div id="rev_slider_1078_1_wrapper" class="rev_slider_wrapper fullwidthbanner-container slide-overlay" data-alias="classic4export" data-source="gallery" style="margin:0px auto;background-color:transparent;padding:0px;margin-top:0px;margin-bottom:0px;">
                
            <!-- START REVOLUTION SLIDER 5.3.0.2 auto mode -->
            <div id="rev_slider_1078_1" class="rev_slider fullwidthabanner" style="display:none;" data-version="5.3.0.2">
                <div class="slotholder"></div>

                    <ul><!-- SLIDE  -->
                    
                        <!-- SLIDE 1 -->
                        <li data-index="rs-3050" data-transition="fade" data-slotamount="7" data-hideafterloop="0" data-hideslideonmobile="off"  data-easein="Power4.easeInOut" data-easeout="Power4.easeInOut" data-masterspeed="2000"    data-rotate="0"  data-saveperformance="off"  data-title="Ken Burns" data-param1="" data-param2="" data-param3="" data-param4="" data-param5="" data-param6="" data-param7="" data-param8="" data-param9="" data-param10="" data-description="">                        
                            <!-- <div class="overlay">
                            </div> -->
                            <!-- MAIN IMAGE -->
                            <img src="images/genslide1.jpg"  alt=""  data-bgposition="center center" data-kenburns="off" data-duration="30000" data-ease="Linear.easeNone" data-scalestart="100" data-scaleend="120" data-rotatestart="0" data-rotateend="0" data-offsetstart="0 0" data-offsetend="0 0" data-bgparallax="10" data-bgfit="contain" class="rev-slidebg" data-no-retina>
                            <!-- LAYERS -->
                          

                        </li>

                        <li data-index="rs-3051" data-transition="fade" data-slotamount="7" data-hideafterloop="0" data-hideslideonmobile="off"  data-easein="Power4.easeInOut" data-easeout="Power4.easeInOut" data-masterspeed="2000"    data-rotate="0"  data-saveperformance="off"  data-title="Ken Burns" data-param1="" data-param2="" data-param3="" data-param4="" data-param5="" data-param6="" data-param7="" data-param8="" data-param9="" data-param10="" data-description="">                        
                            <!-- <div class="overlay">
                            </div> -->
                            <!-- MAIN IMAGE -->
                            <img src="images/genslide2.jpg"  alt=""  data-bgposition="center center" data-kenburns="off" data-duration="30000" data-ease="Linear.easeNone" data-scalestart="100" data-scaleend="120" data-rotatestart="0" data-rotateend="0" data-offsetstart="0 0" data-offsetend="0 0" data-bgparallax="10" data-bgfit="contain" class="rev-slidebg" data-no-retina>
                            <!-- LAYERS -->
                           

                        </li>
                        
                          <li data-index="rs-3051" data-transition="fade" data-slotamount="7" data-hideafterloop="0" data-hideslideonmobile="off"  data-easein="Power4.easeInOut" data-easeout="Power4.easeInOut" data-masterspeed="2000"    data-rotate="0"  data-saveperformance="off"  data-title="Ken Burns" data-param1="" data-param2="" data-param3="" data-param4="" data-param5="" data-param6="" data-param7="" data-param8="" data-param9="" data-param10="" data-description="">                        
                            <!-- <div class="overlay">
                            </div> -->
                            <!-- MAIN IMAGE -->
                            <img src="images/genslide3.jpg"  alt=""  data-bgposition="center center" data-kenburns="off" data-duration="30000" data-ease="Linear.easeNone" data-scalestart="100" data-scaleend="120" data-rotatestart="0" data-rotateend="0" data-offsetstart="0 0" data-offsetend="0 0" data-bgparallax="10" data-bgfit="contain" class="rev-slidebg" data-no-retina>
                            <!-- LAYERS -->
                           

                        </li>

                    </ul>
            </div>
        </div><!-- END REVOLUTION SLIDER --> 
<div class="row">
                    <div class="col-md-12" style="width:100%;">
                        <script type="text/javascript" src="https://files.coinmarketcap.com/static/widget/coinMarquee.js"></script><div id="coinmarketcap-widget-marquee" coins="1,1027,2,1831,1958,1321,5617,5665,52,825,2010" currency="USD" theme="light" transparent="false" show-symbol-logo="true" ></div>
                        
                    </div>
                </div>      
 <section class="flat-row row-counter style2 parallax parallax3">
            <div class="overlay bg_color1"></div>
            <div class="container">
              
     
                 <!-- ##### Cool Facts Area Start ##### -->
        <div class="cool-facts-area">
            <div class="container">
                <div class="row">
                    <div class="col-12 col-sm-6 col-md-3">
                        <!-- Single Cool Fact -->
                        <div class="single_cool_fact text-center wow fadeInUp" data-wow-delay="0.2s">
                            <div class="cool_fact_icon">
                                <i class="ti-user"></i>
                            </div>
                            <!-- Single Cool Detail -->
                            <div class="cool_fact_detail">
                                <h3>$ <span class="counter">4650823</span></h3>
                                <h2>Total Investment</h2>
                            </div>
                        </div>
                    </div>
                    <div class="col-12 col-sm-6 col-md-3">
                        <!-- Single Cool Fact -->
                        <div class="single_cool_fact text-center wow fadeInUp" data-wow-delay="0.3s">
                            <div class="cool_fact_icon">
                                <i class="ti-check"></i>
                            </div>
                            <!-- Single Cool Detail -->
                            
                            <div class="cool_fact_detail">
                                <h3>$ <span class="counter">3383233</span></h3>
                                <h2>Total Withdrawal</h2>
                            </div>
                        </div>
                    </div>
                    <div class="col-12 col-sm-6 col-md-3">
                        <!-- Single Cool Fact -->
                        <div class="single_cool_fact text-center wow fadeInUp" data-wow-delay="0.4s">
                            <div class="cool_fact_icon">
                                <i class="ti-shortcode"></i>
                            </div>
                            
                            <!-- Single Cool Detail -->
                            <?php $rd = rand(01234,56789); ?>
                            
                            <div class="cool_fact_detail">
                                <h3><span class="counter"><?php echo $rd; ?></span>+</h3>
                                <h2>Investors Online</h2>
                            </div>
                        </div>
                    </div>
                    <div class="col-12 col-sm-6 col-md-3">
                        <!-- Single Cool Fact -->
                        <div class="single_cool_fact text-center wow fadeInUp" data-wow-delay="0.5s">
                            <div class="cool_fact_icon">
                                <i class="ti-cup"></i>
                            </div>
                            <!-- Single Cool Detail -->
                            <div class="cool_fact_detail">
                                <h3><span class="counter">127</span></h3>
                                <h2>Supported Countries</h2>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- ##### Cool Facts Area End ##### -->

                
                
     
            </div><!-- /.container -->
        </section><!-- /.flat-row -->

        <section class="flat-row flat-fees">
            <div class="container">
                <div class="row" id="rw">
                    <div class="col-lg-5">
                        <div class="flat-column style2">
                            <div class="title-section style6">
                                <h2 class="title">
                                    UP 7% REFERRAL COMMISSION

                                </h2>
                                <div class="sub-title">
                                    Earn huge bonus when you invite your friends using your unique link. 
                                </div>
                            </div>
                            <div class="content-text">
                                <p></p>
                                <div class="btn-more">
                                    <a href="account/index.php" class="flat-button bg_color1">JOIN US NOW</a>
                                </div>
                            </div>
                        </div><!-- /.flat-column -->
                    </div><!-- /.col-lg-5 -->
                    <div class="col-lg-7">
                        <div class="flat-column">
                            <br />
                          
                            <iframe width="100%" height="350" src="https://www.youtube.com/embed/iCZKAAGABHg" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
 
                        </div><!-- /.flat-column -->
                    </div><!-- /.col-lg-7 -->
                </div><!-- /.row -->
            </div><!-- /.container -->
        </section><!-- /.flat-row -->
        
        <section class="flat-row row-convert">
            <div class="container">
                <div class="row">
                    <div class="col-md-12">
                        <div class="title-section style1 style4 text-center">
                            <h2 class="title">
                               WHAT DO WE OFFER TO OUR INVESTORS?
                            </h2>
                            <p class="sub-title">
                                Largest Cloud Crypto Mining Platform
                            </p>
                        </div>
                        <div class="flat-convert">
                           <div class="row">
                                <div class="col-md-4"><center>
                                    <img src="images/offericon1.png" />
                                    <h6 style="color:#ffcc00;">UNIFORM LUCRATIVE MATURITY</h6>
                                    <p style="color:white; font-size:14px;">GENESIS MINING is a competent and strong franchise which offers consecutive growth on your existing finances on an continuous cyclic basis.</p>
                                    
                                    </center></div>
                               
                                <div class="col-md-4"><center>
                                    <img src="images/offericon2.png" />
                                     <h6 style="color:#ffcc00;">PROMPT RETREATS</h6>
                                    <p style="color:white; font-size:14px;">Our all retreats are treated spontaneously once requested. There is not maximum limits. Minimum Withdrawal is $100.</p>
                                    </center></div>
                               
                                <div class="col-md-4"><center>
                                    <img src="images/offericon3.png" />
                                     <h6 style="color:#ffcc00;">PROFESSIONAL SUPPORT</h6>
                                    <p style="color:white; font-size:14px;">We provide 24/7 customer support through e-mail and live chat. Our support representatives are periodically available to elucidate any difficulty.</p>
                                    </center></div>
                            </div>
                        </div><!-- /.flat-convert -->
                    </div><!-- /.col-md-12 -->
                </div><!-- /.row -->
            </div><!-- /.container -->
        </section><!-- /.flat-row -->
        
        <section class="flat-row row-choosing">
            <div class="container">
                <div class="row" style="margin-top: -100px;">
                    <div class="col-md-12">
                        <div class="flat-choosing clearfix">
                            <div class="title-section style1 style4 text-center">
                                <h2 class="title" style="color:#00001a;">GENESIS MINING SECURITY FEATURES?</h2>
                            </div>
                            <div class="choosing-content">
                              
                            </div>
                        </div><!-- /.flat-choosing -->
                    </div><!-- /.col-md-12 -->
                </div>
                <div class="row">
                    <div class="col-md-3 panel panel-body"><div style="margin-bottom:10px; background-color:#006600; border-radius:10px;  width:90%; margin-left:5%;"><center><img src="images/sitelock.png" /></center></div></div>
                    <div class="col-md-3 panel panel-body"><div style="margin-bottom:10px; background-color:#009999; border-radius:10px;  width:90%; margin-left:5%;"><center><img src="images/geotrust.png" /></center></div></div>
                    <div class="col-md-3 panel panel-body"><div style="margin-bottom:10px; background-color:#000066; border-radius:10px;  width:90%; margin-left:5%;"><center><img src="images/mcafree.png" /></center></div></div>
                    <div class="col-md-3 panel panel-body"><div style="margin-bottom:10px; background-color:#ff6600; border-radius:10px;  width:90%; margin-left:5%;"><center><img src="images/trustguard.png" /></center></div></div>
                    
                </div>
                
                <!-- /.row -->
            </div><!-- /.container -->
        </section><!-- /.flat-row -->

           <section class="flat-row row-testimonials parallax parallax4">
            <div class="overlay bg_color1"></div>
            <div class="container">
                <div class="row" id="rw">
                    <div class="col-md-12">
                        <div class="wrap-testimonials text-center">
                            <div class="flat-testimonials" data-item="1" data-nav="false" data-dots="false" data-auto="true">
                                 <div class="testimonials">
                                    <div class="avatar">
                                        <div class="author-thumb">
                                            <img src="images/t1.jpg" style="border-radius:100px;" alt="image">
                                        </div>
                                        <div class="name"><span>Guy Corem, CEO Spondoolies-Tech Leading Bitcoin Asic Manufacturing Company</span></div>
                                    </div>
                                    <div class="message">
                                        <blockquote>
                                            <p>Genesis Mining is one of the leading cloudmining companies and a trustworthy partner of ours. It’s good to see that they are an honest cloudmining service which shows their farms openly to the public. </p>
                                        </blockquote>
                                    </div>
                                </div><!-- /.testimonials -->
                                <div class="testimonials">
                                    <div class="avatar">
                                        <div class="author-thumb">
                                            <img src="images/t2.jpg" style="border-radius:100px; border:1px solid white;" alt="image">
                                        </div>
                                        <div class="name"><span>Terry Li, CEO Zeus Leading Scrypt Asic Manufacturing Company</span></div>
                                    </div>
                                    <div class="message">
                                        <blockquote>
                                            <p>Genesis Mining is one of our biggest clients and proven to be a reliable and trustworthy business partner. Their transparent mining sites and high quality software infrastructure together with our high end mining hardware result in a great and unique product and experience for everybody interested in mining! </p>
                                        </blockquote>
                                    </div>
                                </div><!-- /.testimonials -->
                                <div class="testimonials">
                                    <div class="avatar">
                                        <div class="author-thumb">
                                            <img src="images/t3.png" style="border-radius:100px; border:1px solid white;" alt="image">
                                        </div>
                                        <div class="name"><span>Alex, VP of business development, from Innosilicon</span></div>
                                    </div>
                                    <div class="message">
                                        <blockquote>
                                            <p>As the world first 28nm BTC and LTC chip maker, Innosilicon selects Genesis Ming as partner in cloud mining industry business for its integrity, excellent customer oriented service and great user interface design. Genesis Mining is the best in class mining service that is supported by our technologically superior mining hardware. This unique synergy produces the best experience for those interested in mining and we look forward to having a long and prosperous relationship.</p>
                                        </blockquote>
                                    </div>
                                </div><!-- /.testimonials -->
                                 <div class="testimonials">
                                    <div class="avatar">
                                        <div class="author-thumb">
                                            <img src="images/t4.png" style="border-radius:100px; border:1px solid white;" alt="image">
                                        </div>
                                        <div class="name"><span> Jing Wei, CEO of MinerEU, Official Distribution Partner of Genesis Mining</span></div>
                                    </div>
                                    <div class="message">
                                        <blockquote>
                                            <p>MinerEU is very happy to have Genesis Mining as our trustworthy partner. We have already recommended Genesis-Mining to thousands of our existing customers who are happy and satisfied with their excellent services and products.</p>
                                        </blockquote>
                                    </div>
                                </div><!-- /.testimonials -->
                            </div><!-- /.flat-testimonials -->
                        </div><!-- /.wrap-testimonials -->
                    </div><!-- /.col-md-12 -->
                </div><!-- /.row -->
            </div><!-- /.container -->
        </section><!-- /.flat-row -->

        
        <section class="flat-row flat-bysell style3">
            <div class="container">
                <div class="row" id="rw">
                    <div class="col-md-12">
                        <div class="">
                            <div class="flat-column box-text">
                                <div class="title-section style7">
                                    <div class="sub-title">
                                        Get to know about us
                                    </div>
                                    <h2 class="title">
                                        About Genesis Mining?
                                    </h2>
                                </div>
                                <div class="content-text" >
                                    <p>The story of Genesis Mining started at the end of 2013. Our founders got to know each other by using the same platform for buying and selling Bitcoins. They were fascinated by the technology and wanted to build their own farm, only to realize all their friends wanted to participate as well.<br />
                                    
                                        They came up with the idea of mining as a service and built the first mining farm in Eastern Europe. Since our founding, we have grown tremendously and a lot has happened, but one thing remains constant: We are all strong believers in the future of digital currencies and we love being part of this growing community.
                                    </p>
                                   
                                </div>
                            </div><!-- /.flat-column -->
                           <!-- /.flat-column -->
                        </div><!-- /.wrap-column -->
                    </div>
                </div>
               
                <!-- /.row -->
            </div><!-- /.container -->
        </section><!-- /.flat-row -->

        <section class="flat-row row-convert">
            <div class="container">
                <div class="row" id="rw">
                    <div class="col-md-12">
                        <div class="title-section style1 style4 text-center">
                            <h2 class="title">
                              We Are LEGAL
                            </h2>
                            <p class="sub-title">
                                We are legit and your investment is secure with us
                            </p>
                        </div>
                     <div class="row" style="width:80%; margin-left:10%;">
                   
                     <div class="col-md-6">
                                <img src="images/cert2.png" alt="image">
                            </div>
                         
                     <div class="col-md-6">
                                <img src="images/cert1.png" alt="image">
                            </div><!-- /.col-md-12 -->
                </div>
                    
                    </div><!-- /.col-md-12 -->
                </div><!-- /.row -->
            </div><!-- /.container -->
        </section><!-- /.flat-row -->
       
         
     
        <section class="flat-row row-chart style2">
            <div class="container">
                <div class="row" style="margin-top: -100px;">
                    <div class="col-md-12">
                    
                        
                         <div class="title-section style1 style4 text-center" style="color:#00091a;">
                            <h2 class="title" style="color:#00091a;">
                              OUR PROFITABLE MINING PLANS
                            </h2>
                            <p class="sub-title" style="color:#00091a;">
                                We propose to you a finance system to choose not only for settlements but also for the possibility to earn the most extraordinary profit.
                            </p>
                        </div>
                    </div><!-- /.col-md-12 -->
                </div><!-- /.row --> 
                <div class="divider h24"></div>
               
                <div class="row">
                    <div class="col-md-3">
                        <div class="panel panel-body" style="width:98%; margin-left:1%; margin-bottom:20px; background-color:#0d1a26; border-radius:15px;">
                            <br />
                            <center><h4 style="color:white;">TRAINEE</h4></center>
                            <br />
                            <div style="background-color:white; border:3px solid #ffcc00; text-align:center; border-radius:150px; padding:10px; width:50%; margin-left:25%;"><h2 style="color:#0d1a26">15 %</h2><p style="font-size:12px;">ROI In 12 Hours</p></div>
                            
                            <br />
                            <br />
                            <div style="background-color:white; border:3px solid #ffcc00; text-align:center; border-radius:25px; width:80%; margin-left:10%;"><p><tr><td>Minimum:</td><td>$60 <i class="fa fa-check"></i></td></tr></p></div>
                            <br />
                            <div style="background-color:white; border:3px solid #ffcc00; text-align:center; border-radius:25px; width:80%; margin-left:10%;"><p><tr><td>Maximum:</td><td>$200 <i class="fa fa-check"></i></td></tr></p></div>
                            <br />
                            <center><a href="account/index.php" class="btn btn-success" style="border-radius:20px;">INVEST NOW</a></center>
                            <br />
                        </div>
                    </div>
                    
                     <div class="col-md-3">
                        <div class="panel panel-body" style="width:98%; margin-left:1%; margin-bottom:20px; background-color:#0d1a26; border-radius:15px;">
                            <br />
                            <center><h4 style="color:white;">STANDARD</h4></center>
                            <br />
                            <div style="background-color:white; border:3px solid #ffcc00; text-align:center; border-radius:150px; padding:10px; width:50%; margin-left:25%;"><h2 style="color:#0d1a26">35 %</h2><p style="font-size:12px;">ROI in 24 Hours</p></div>
                            
                            <br />
                            <br />
                            <div style="background-color:white; border:3px solid #ffcc00; text-align:center; border-radius:25px; width:80%; margin-left:10%;"><p><tr><td>Minimum:</td><td>$210 <i class="fa fa-check"></i></td></tr></p></div>
                            <br />
                            <div style="background-color:white; border:3px solid #ffcc00; text-align:center; border-radius:25px; width:80%; margin-left:10%;"><p><tr><td>Maximum:</td><td>$1,000 <i class="fa fa-check"></i></td></tr></p></div>
                            <br />
                            <center><a href="account/index.php" class="btn btn-success" style="border-radius:20px;">INVEST NOW</a></center>
                            <br />
                        </div>
                    </div>
                    
                     <div class="col-md-3">
                        <div class="panel panel-body" style="width:98%; margin-left:1%; margin-bottom:20px; background-color:#0d1a26; border-radius:15px;">
                            <br />
                            <center><h4 style="color:white;">GOLD</h4></center>
                            <br />
                            <div style="background-color:white; border:3px solid #ffcc00; text-align:center; border-radius:150px; padding:10px; width:50%; margin-left:25%;"><h2 style="color:#0d1a26">50 %</h2><p style="font-size:12px;">ROI in 48 Hours</p></div>
                            
                            <br />
                            <br />
                            <div style="background-color:white; border:3px solid #ffcc00; text-align:center; border-radius:25px; width:80%; margin-left:10%;"><p><tr><td>Minimum:</td><td>$1,001 <i class="fa fa-check"></i></td></tr></p></div>
                            <br />
                            <div style="background-color:white; border:3px solid #ffcc00; text-align:center; border-radius:25px; width:80%; margin-left:10%;"><p><tr><td>Maximum:</td><td>Unlimited <i class="fa fa-check"></i></td></tr></p></div>
                            <br />
                            <center><a href="account/index.php" class="btn btn-success" style="border-radius:20px;">INVEST NOW</a></center>
                            <br />
                        </div>
                    </div>
                    
                    
                     <div class="col-md-3">
                        <div class="panel panel-body" style="width:98%; margin-left:1%; margin-bottom:20px; background-color:#0d1a26; border-radius:15px;">
                            <br />
                            <center><h4 style="color:white;">CLASSIC</h4></center>
                            <br />
                            <div style="background-color:white; border:3px solid #ffcc00; text-align:center; border-radius:150px; padding:10px; width:50%; margin-left:25%;"><h2 style="color:#0d1a26">250 %</h2><p style="font-size:12px;">ROI in 18 hours</p></div>
                            
                            <br />
                            <br />
                            <div style="background-color:white; border:3px solid #ffcc00; text-align:center; border-radius:25px; width:80%; margin-left:10%;"><p><tr><td>Minimum:</td><td>$700 <i class="fa fa-check"></i></td></tr></p></div>
                            <br />
                            <div style="background-color:white; border:3px solid #ffcc00; text-align:center; border-radius:25px; width:80%; margin-left:10%;"><p><tr><td>Maximum:</td><td>Unlimited <i class="fa fa-check"></i></td></tr></p></div>
                            <br />
                            <center><a href="account/index.php" class="btn btn-success" style="border-radius:20px;">INVEST NOW</a></center>
                            <br />
                        </div>
                    </div>
                    
                  
                </div>
                
               
                <!-- /.row -->
            </div><!-- /.container -->
        </section><!-- /.flat-row -->

      
        <section class="flat-row flat-download-divice">
            <div class="container">
                <div class="row">
                    <div class="col-md-12">
                        <div class="title-download text-center">
                            <h2 class="title">
                                It’s never too late to get started. 
                            </h2>
                          <!--  <div class="sub-title">
                                Download for you device
                            </div> -->
                        </div>
                        <ul class="thumb-apps text-center">
                            <img src="images/1d7d14dcd2872d5d99f486ae94bda8ed.gif" alt="image">
                            
                        </ul><!-- /.thumb-apps -->
                    </div>
                    <div class="col-md-3"><br /><center><img src="images/btc.png" style="width:225px; height:224px;" /></center></div>
                    <div class="col-md-3"><br /><center><img src="images/ltc.png" style="width:225px; height:224px;" /></center></div>
                    <div class="col-md-3"><br /><center><img src="images/eth2.png" style="width:225px; height:224px;" /></center></div>
                    <div class="col-md-3"><br /><center><img src="images/xrp.png" style="width:225px; height:224px;" /></center></div>
                    <!-- /.col-md-12 -->
                </div><!-- /.row -->
            </div><!-- /.container -->
        </section><!-- /.flat-download-divice -->
        
     <section class="flat-row flat-partners">
            <div class="container">
                <ul class="flat-client" data-item="4" data-nav="false" data-dots="false" data-auto="true">
                    <li>
                        <img src="images/bitforex.png" alt="image">
                    </li>
                    <li>
                        <img src="images/changelly.png" alt="image">
                    </li>
                    <li>
                        <img src="images/exmo.png" alt="image">
                    </li>
                    <li>
                        <img src="images/liquid.png" alt="image">
                    </li>
                     <li>
                        <img src="images/livecoin.png" alt="image">
                    </li>
                </ul>
            </div><!-- /.container -->
        </section><!-- /.flat-partners -->
        
     
        
       
        
     
        
        <footer class="footer">
            <div class="footer-widgets">
                <div class="container">
                    <div class="row">
                        <div class="col-md-4">
                            <div class="widget widget-brand">
                                <div class="logo logo-footer">
                                    <a href="index-2.html">
                                        <img src="images/logofoot.png" alt="image">
                                    </a>
                                </div>
                            </div><!-- /.widget-brand -->
                           <p>It’s super simple - Your mining rigs are already set up and running.
As soon as you’ve set up your account, you can start to mine your first coins using our Bitcoin cloud mining service!</p>
                            <p><img src="images/cards.png" /></p>
                        </div><!-- /.col-md-4 -->

                        <div class="col-md-4">
                            <div class="wiget widget-services">
                                <div class="one-half">
                                    <h5 class="widget-title">
                                        POLICY
                                    </h5>
                                    <ul>
                                        <li><a href="terms.php">Terms & Conditions</a></li>
                                        
                                    </ul>
                                </div>
                                <div class="one-half padding_left_73">
                                    <h5 class="widget-title">
                                        SHORT LINK
                                    </h5>
                                    <ul>
                                        <li><a href="how-it-works.php?user=<?php echo $user; ?>">HOW IT WORKS</a></li>
                                        <li><a href="about.php?user=<?php echo $user; ?>">ABOUT US</a></li>
                                        <li><a href="account/index.php">Sign up</a></li>
                                       
                                    </ul>
                                </div>
                            </div><!-- /.widget-services -->
                        </div><!-- /.col-md-4 -->

                        <div class="col-md-4">
                           <div class="widget widget-subscribe">
                               <h5 class="widget-title">
                                  Contact
                               </h5>
                               
                               <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d2483.9643070527623!2d-0.1439769842304674!3d51.49552247963327!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x48760520699914a3%3A0x5cd003928ff56827!2s302%20Vauxhall%20Bridge%20Rd%2C%20Westminster%2C%20London%2C%20UK!5e0!3m2!1sen!2sng!4v1616493487737!5m2!1sen!2sng" width="100%" height="200" style="border:0;" allowfullscreen="" loading="lazy"></iframe>
                               
                                <p>302 Vauxhall Bridge Road, London, England, SW1V 1AA</p>
                               
                                <p>
                                    Email: support@onegenesisinc.com<br /> Phone: +44-7003200284
                                </p>
                               
                           </div>
                        </div><!-- /.col-md-4 -->
                    </div><!-- /.row -->
                </div><!-- /.container -->
            </div><!-- /.footer-widgets -->
        </footer><!-- /.footer -->

        <div class="footer-bottom">
            <div class="container">
                <div class="row">
                    <div class="col-md-12">
                        <p class="copyright text-center">&copy; Copyright 2013-2021, All rights reserved. Genesis-Mining</p>
                    </div>
                </div>
            </div>
        </div><!-- /.footer-bottom -->

        <!-- Go Top -->
        <a class="go-top">
            <i class="fa fa-chevron-up"></i>
        </a>  

    </div>
    
    <!-- Javascript -->
    <script src="javascript/jquery.min.js"></script>
    <script src="javascript/tether.min.js"></script>
    <script src="javascript/bootstrap.min.js"></script>
    <script src="javascript/jquery.easing.js"></script>    
    <script src="javascript/parallax.js"></script>
    <script src="javascript/owl.carousel.js"></script>
    <script src="javascript/jquery-countTo.js"></script>
    <script src="javascript/jquery-waypoints.js"></script>
    <script src="javascript/jquery-validate.js"></script>
    <script src="javascript/jquery.cookie.js"></script>
    <script src="javascript/plotly-latest.min.js"></script>
    <script src="javascript/jquery.easeScroll.js"></script>
    <script src="javascript/gmap3.min.js"></script>
    <script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyDLjIsk1A1SP8UsfNf2r4VXPinzvnIsnN4&amp;region=GB"></script>
    <script src="javascript/main.js"></script>

    <!-- Revolution Slider -->
    <script src="revolution/js/jquery.themepunch.tools.min.js"></script>
    <script src="revolution/js/jquery.themepunch.revolution.min.js"></script>
    <script src="revolution/js/slider.js"></script>
    
    
     <!-- All Plugins js -->
    <script>
    (function(e){"use strict";e.fn.counterUp=function(t){var n=e.extend({time:400,delay:10},t);return this.each(function(){var t=e(this),r=n,i=function(){var e=[],n=r.time/r.delay,i=t.text(),s=/[0-9]+,[0-9]+/.test(i);i=i.replace(/,/g,"");var o=/^[0-9]+$/.test(i),u=/^[0-9]+\.[0-9]+$/.test(i),a=u?(i.split(".")[1]||[]).length:0;for(var f=n;f>=1;f--){var l=parseInt(i/n*f);u&&(l=parseFloat(i/n*f).toFixed(a));if(s)while(/(\d+)(\d{3})/.test(l.toString()))l=l.toString().replace(/(\d+)(\d{3})/,"$1,$2");e.unshift(l)}t.data("counterup-nums",e);t.text("0");var c=function(){t.text(t.data("counterup-nums").shift());if(t.data("counterup-nums").length)setTimeout(t.data("counterup-func"),r.delay);else{delete t.data("counterup-nums");t.data("counterup-nums",null);t.data("counterup-func",null)}};t.data("counterup-func",c);setTimeout(t.data("counterup-func"),r.delay)};t.waypoint(i,{offset:"100%",triggerOnce:!0})})}})(jQuery);
    </script>

    <!-- script js -->
    <script src="js2/script.js"></script>

    <!-- SLIDER REVOLUTION 5.0 EXTENSIONS  (Load Extensions only on Local File Systems !  The following part can be removed on Server for On Demand Loading) -->    
    <script src="revolution/js/extensions/revolution.extension.actions.min.js"></script>
    <script src="revolution/js/extensions/revolution.extension.carousel.min.js"></script>
    <script src="revolution/js/extensions/revolution.extension.kenburn.min.js"></script>
    <script src="revolution/js/extensions/revolution.extension.layeranimation.min.js"></script>
    <script src="revolution/js/extensions/revolution.extension.migration.min.js"></script>
    <script src="revolution/js/extensions/revolution.extension.navigation.min.js"></script>
    <script src="revolution/js/extensions/revolution.extension.parallax.min.js"></script>
    <script src="revolution/js/extensions/revolution.extension.slideanims.min.js"></script>
</body> 

</html>                               