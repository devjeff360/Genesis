<?php

$server = "localhost";
$dbUsername = "root";
$dbPassword = "";
$dbName = "genesis";

$con = new mysqli($server, $dbUsername, $dbPassword, $dbName) or die("Connection Failed %s\n". $con -> error);

?>