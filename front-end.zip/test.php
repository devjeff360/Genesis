<?php



$to = "sureaza05@gmail.com";
$fname = "Babatunde";
$lname = "Olulaja";
$pass = "1111";
$smail = "";
$user = "devjeff";
$fn = "$fname $lname";


 $subject = "WELCOME TO GENESISMINING";
 
 $body = '<html lang="en" xmlns="http://www.w3.org/1999/xhtml" xmlns:v="urn:schemas-microsoft-com:vml" xmlns:o="urn:schemas-microsoft-com:office:office"><head>
    <meta charset="utf-8"> 
    <meta name="viewport" content="width=device-width"> 
    <meta http-equiv="X-UA-Compatible" content="IE=edge"> 
    <meta name="x-apple-disable-message-reformatting"> 
    <title></title>

    <link href="https://fonts.googleapis.com/css?family=Work+Sans:200,300,400,500,600,700" rel="stylesheet">



   


</head>

<body width="100%" style="margin: 0; padding: 0 !important; mso-line-height-rule: exactly; background-color: #f1f1f1;">
	<center style="width: 100%; background-color: #f1f1f1;">
    <div style="display: none; font-size: 1px;max-height: 0px; max-width: 0px; opacity: 0; overflow: hidden; mso-hide: all; font-family: sans-serif;">
      &zwnj;&nbsp;&zwnj;&nbsp;&zwnj;&nbsp;&zwnj;&nbsp;&zwnj;&nbsp;&zwnj;&nbsp;&zwnj;&nbsp;&zwnj;&nbsp;&zwnj;&nbsp;&zwnj;&nbsp;&zwnj;&nbsp;&zwnj;&nbsp;&zwnj;&nbsp;&zwnj;&nbsp;&zwnj;&nbsp;&zwnj;&nbsp;&zwnj;&nbsp;&zwnj;&nbsp;
    </div>
    <div style="max-width: 600px; margin: 0 auto;" class="">
    	
      <table align="center" role="presentation" cellspacing="0" cellpadding="0" border="0" width="100%" style="margin: auto;border-spacing: 0 !important;border-collapse: collapse !important;table-layout: fixed !important;margin: 0 auto !important;">
      	<tbody><tr>
          <td valign="top" style="background:#000000" style="padding: 1em 2.5em 0 2.5em;">
          	<table role="presentation" border="0" cellpadding="0" cellspacing="0" width="100%">
          		<tbody><tr style="border-bottom:1px solid">
          			<td class="logo" style="text-align: center;">
			            <h1><img alt="GENESIS LOGO" border="0" src="https://onegenesisinc.com/images/logofoot.png" ></h1>
			          </td>
          		</tr>
          	</tbody></table>
          </td>
	      </tr>
				
            </tbody></table>
          </td>
	      </tr>
	      <tr></tr>
		 </tbody>
		</table>
        
        <p><b>WELCOME TO GENESISMINING</b><br />
Hello '.$fn.',

Your account has been successfully created, you can now login and start mining with the most profitable mining company.


GENESISMINING cloud mining offers you a smart and easy way to invest in bitcoin with zero stress. Our company is initiated by a group of experts engaged in various speculative transactions giving high percent on earnings of investment funds.


At GENESISMINING, we have a well structured investment plan that will suit every budget, you will get periodic bitcoin mining profits to your account every hour of your invested package, withdraw-able anytime.
</p>
			
		 <h3>Login Details</h3>
            <p>Email:   Your email address<br />
            Password:   '.$pass.'</p>
            
            <p>Regards,<br />
GENESISMINING<br />
Bitcoin Cloud Mining</p>
      
		<div style="border-top:1px solid white;"></div>
		<table align="center" role="presentation" cellspacing="0" cellpadding="0" border="0" width="100%" style="margin: auto;background:#000000;border-spacing: 0 !important;border-collapse: collapse !important;table-layout: fixed !important;margin: 0 auto !important;">
			<tbody>
				<tr>				
				  <td class="" style="text-align: center;background:#0d1a26">
					<p style="color: white;font-size:11px;padding:5px;"><br>© 2013-2021 GenesisMining  Limited. All rights reserved</p>
				  </td>				
				</tr>
		    </tbody>
	    </table>

    </div>
  </center>

</body></html>';


                     
                    
					
	$headers .='Reply-To: '. $to . "\r\n" ;
    $headers .='X-Mailer: PHP/' . phpversion();
   $headers .="MIME-Version: 1.0\r\n";
					$headers .="Content-Type: text/html; charset=ISO-8859-1\r\n";
		
					  
if(mail($to,$subject,$body,$headers, '-f admin@web4all.com.ng -F "WEB4ALL"')) {
    
  echo"SENT";
  } 
  else 
  {
 header("Location: https://onegenesisinc.com/account/index.php");
  }

?>

