<?php

    $user = $_GET['user'];
?>
<!DOCTYPE html>
<!--[if IE 8 ]><html class="ie" xmlns="http://www.w3.org/1999/xhtml" xml:lang="en-US" lang="en-US"> <![endif]-->
<!--[if (gte IE 9)|!(IE)]><!--><html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en-US" lang="en-US"><!--<![endif]-->

<head>
    <!-- Basic Page Needs -->
    <meta charset="utf-8">
    <!--[if IE]><meta http-equiv='X-UA-Compatible' content='IE=edge,chrome=1'><![endif]-->
    <title>how it works || Genesis Mining</title>

    <meta name="author" content="themesflat.com">

    <!-- Mobile Specific Metas -->
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">

    <!-- Bootstrap  -->
    <link rel="stylesheet" type="text/css" href="stylesheets/bootstrap.css" >

    <!-- Theme Style -->
    <link rel="stylesheet" type="text/css" href="stylesheets/style.css">

    <!-- Responsive -->
    <link rel="stylesheet" type="text/css" href="stylesheets/responsive.css">

    <!-- Animation Style -->
    <link rel="stylesheet" type="text/css" href="stylesheets/animate.css">

    <!-- REVOLUTION LAYERS STYLES -->
    <link rel="stylesheet" type="text/css" href="revolution/css/layers.css">
    <link rel="stylesheet" type="text/css" href="revolution/css/settings.css">

    <!-- Favicon and touch icons  -->
    <link href="images/genfav.jpg" rel="shortcut icon">
    
    

     <style>
       
         
         /* ##### 10.0 Cool Fact Area CSS ##### */

.cool-facts-area {
    padding: 50px 0 30px;

}

.single_cool_fact {
    position: relative;
    z-index: 1;
    
    border: 1px solid #fff;
    border-bottom: 3px solid #fff;
    border-radius: 0 0 20px 20px;
    padding: 30px;
    overflow: hidden;
    margin-bottom: 30px;
}


.cool_fact_icon i {
    font-size: 100px;
    position: absolute;
    top: 50%;
    left: 50%;
    transform: translate(-50%, -50%);
    opacity: .1;
    color: #242020;
    font-weight: 800;
}

.cool_fact_detail h3 {
    font-size: 35px;
    font-weight: 600;
    margin-top: 0 !important;
    margin-top: 15px;
    color: #fff !important;
}

.cool_fact_detail h2 {
    font-size: 14px;
    margin-bottom: 0;
    color: #fff !important;
    text-transform: uppercase;
}
  
    .payment-logos img {
  width: 30px;
  margin-right: 5px;
}

.payment-logos img.last {
  margin-right: 0;
}
    </style>
   

    <!--[if lt IE 9]>
        <script src="javascript/html5shiv.js"></script>
        <script src="javascript/respond.min.js"></script>
    <![endif]-->
    
    <style>
        svg{
            width: 250px;
            height:125px;
        }
    </style>
    <script src="//code.jivosite.com/widget/0MPNPGglUA" async></script>
</head> 
<body class="header_sticky">
    <!-- Preloader -->
    <section class="loading-overlay">
       <div class="loading-page">
            <div class="loader"></div>
        </div>
    </section>  

    <!-- Boxed -->
    <div class="boxed">
        
        <div class="top">
            <div class="container">
                <div class="row">
                    <div class="col-md-4">
                        <div class="wrap-language-info clearfix">
                            <ul class="flat-info">
                               <p><?php echo $date = date("D, M d, Y"); ?></p>
                            </ul><!-- /.flat-info -->
                           <!-- /.flat-language -->
                        </div><!-- /.wrap-language-info -->
                    </div><!-- /.clo-md-6 -->
                    <div class="col-md-8">
                        <div class="wrap-social-sign pull-right clearfix">
                            <ul class="flat-social"><li>
                             <div id="ytWidget"></div><script src="https://translate.yandex.net/website-widget/v1/widget.js?widgetId=ytWidget&pageLang=en&widgetTheme=dark&autoMode=false" type="text/javascript"></script><!-- /.flat-social -->    
                                
                            </li></ul>
                           
                            <div class="flat-sign">
                                <a href="account/index.php">Sign in</a>
                                <a href="account/index.php" class="active">Sign Up</a>
                            </div><!-- /.flat-sign -->
                        </div><!-- /.wrap-social-sign -->
                    </div><!-- /.col-md-6 -->
                </div><!-- /.row -->
            </div><!-- /.container -->
        </div><!-- /.top -->

        <div class="flat-header-wrap">
            <div class="header header-top">
                <div class="container">
                    <div class="row">
                        <div class="col-md-12 col-lg-3">
                            <div id="logo" class="logo">
                                <a href="#" rel="home">
                                    <img src="images/logotop.png" alt="image">
                                </a>
                            </div><!-- /.logo -->
                        </div><!-- /.col-lg-3 -->
                        <div class="col-md-12 col-lg-9">
                           
                        </div><!-- /.col-lg-9 -->
                    </div><!-- /.row -->
                </div><!-- /.container -->
            </div><!-- /.header-top -->

            <header id="header" class="header header-classic">
                <div class="container">
                    <div class="row">
                        <div class="col-md-12">
                            <div class="nav-wrap">
                                <nav id="mainnav" class="mainnav">
                                    <ul class="menu">
                                        <li class="active">
                                            <a href="index.php?user=<?php echo $user; ?>">HOME</a>
                                        </li>
                                        <li >
                                            <a href="about.php?user=<?php echo $user; ?>">ABOUT US</a>
                                        </li>
                                        <li>
                                            <a href="how-it-works.php?user=<?php echo $user; ?>">HOW IT WORKS</a>
                                          
                                        </li>
                                        <li>
                                            <a href="plans.php?user=<?php echo $user; ?>">PLANS</a>
                                        </li>
                                        <li>
                                            <a href="testimony.php?user=<?php echo $user; ?>">TESTIMONY</a>
                                        </li>
                                        <li><a href="contact.php?user=<?php echo $user; ?>">CONTACT US</a></li>
                                    </ul>
                                </nav><!-- /.mainnav -->
                                <ul class="menu-extra">
                                    <li class="search">
                                        <a href="#"><i class="fa fa-search"></i></a>
                                    </li>
                                    <li class="quote">
                                        <a href="account/index.php" title="">Get Started </a>
                                    </li>
                                </ul><!-- /.menu-extra -->
                                <div class="top-search">            
                                    <form role="search" method="get" class="search-form" action="#">
                                        <label>                                    
                                            <input type="search" class="search-field" placeholder="Search …" value="" name="s">
                                        </label>
                                        <span class="fa fa-times close"></span>
                                    </form>       
                                </div><!-- /.top-serach -->
                                <div class="btn-menu">
                                    <span></span>
                                </div><!-- /.mobile menu button -->
                            </div><!-- /.nav-wrap -->
                        </div>
                    </div><!-- /.row -->
                </div><!-- /.container -->
            </header><!-- /header -->
        </div><!-- /.flat-header-wrap -->
        
        <!-- Page title -->
        <div class="page-title parallax parallax1">
            <div class="overlay"></div>
            <div class="container">
                <div class="row">
                    <div class="col-md-12">
                        <div class="page-title-heading">
                            <h1 class="title">How it works.</h1>
                        </div><!-- /.page-title-captions -->
                    </div><!-- /.col-md-12 -->
                </div><!-- /.row -->
            </div><!-- /.container -->                      
        </div><!-- /.page-title -->
        
        <div class="flat-breadcrumbs">
            <div class="container">
                <div class="row">
                    <div class="col-md-12">
                        <div class="breadcrumbs">
                            <ul>
                                <li><a href="index.php?user=<?php echo $user; ?>">HOME</a></li>
                                <li><a href="how-it-works.php?user=<?php echo $user; ?>">HOW IT WORKS</a></li>  
                            </ul>                   
                        </div><!-- /.breadcrumbs -->  
                       
                    </div><!-- /.col-md-12 -->
                </div><!-- /.row -->
            </div><!-- /.container -->
        </div><!-- /.flat-breadcrumbs --> 

  
        <div class="panel panel-body alert" style="width:90%; margin-left:5%; background-color:#3C3A64;">
        <h2 style="color:white;">REGISTER WITH GENESIS-MINING</h2>
<p style="color:white;">To open an account, simply click on the “Sign Up” button on the main page. The next page is the registration form that you need to fill out. This shouldn’t take more than a few minutes. Once you’ve done that, you’ll receive an email confirmation from us, and you’re done. You are now an official member of GENESIS-MINING!</p>
        </div>
        <br />
        
         <div class="panel panel-body alert" style="width:90%; margin-left:5%; background-color:#7ED655;">
        <h2 style="color:white;">LOGIN TO MEMBER’S AREA</h2>
<p style="color:white;">
Once you’ve opened an account, the next thing would be to familiarize yourself with how different sections of your account works. To start, go to the login page and enter your registration username and chosen password. After you are logged in, you can explore your account and get a feel of how everything works, such as making deposits, requesting withdrawals, etc.</p>
        </div>
        <br />
        
         <div class="panel panel-body alert" style="width:90%; margin-left:5%; background-color:#EC2424;">
        <h2 style="color:white;">MAKE YOUR FIRST DEPOSIT</h2>
<p style="color:white;">To start growing your capital, you need to make a deposit. You can do this from the deposit section of your account. There are various investment plans depending on the amount of your deposit. The minimum deposit amount is only $100, and you are allowed to make as many deposits as you want. However, every deposit is treated as a separate investment.</p>
        </div>
        <br />
        
         <div class="panel panel-body alert" style="width:90%; margin-left:5%; background-color:#425EC4;">
        <h2 style="color:white;">WATCH YOUR CAPITAL GROW</h2>
<p style="color:white;">
After you have made a deposit, there is nothing else to do except watch your earnings grow in your account. This can be fun, because it means you can be anywhere you want to be in the world, and your capital will still be growing in your account every day, even without you doing anything!</p>
        </div>
        <br />
        
         <div class="panel panel-body alert" style="width:90%; margin-left:5%; background-color:#F1D433;">
        <h2 style="color:white;">REQUEST WITHDRAWALS</h2>
<p style="color:white;">

It only takes a few seconds to initiate your withdrawals and have your earnings paid to you.At GENESIS-MINING, all the payments perform instantly with alleged security and efficiency in real time.</p>
        </div>
        <br />
        
         <div class="panel panel-body alert" style="width:90%; margin-left:5%; background-color:#995353;">
        <h2 style="color:white;">REFER YOUR FRIENDS</h2>
<p style="color:white;">
You don’t need an active deposit to take advantage of our referral program. As long as you are a registered member, you only need to use your personal affiliate link from your member’s area and share it with your friends. You will get rewarded as soon as they join and make their first deposit!</p>
        </div>
        <br />
        
        
        
        
        
        
          <section class="flat-row flat-partners">
            <div class="container">
                <ul class="flat-client" data-item="4" data-nav="false" data-dots="false" data-auto="true">
                    <li>
                        <img src="images/bitforex.png" alt="image">
                    </li>
                    <li>
                        <img src="images/changelly.png" alt="image">
                    </li>
                    <li>
                        <img src="images/exmo.png" alt="image">
                    </li>
                    <li>
                        <img src="images/liquid.png" alt="image">
                    </li>
                     <li>
                        <img src="images/livecoin.png" alt="image">
                    </li>
                </ul>
            </div><!-- /.container -->
        </section><!-- /.flat-partners -->
        
        <footer class="footer">
            <div class="footer-widgets">
                <div class="container">
                    <div class="row">
                        <div class="col-md-4">
                            <div class="widget widget-brand">
                                <div class="logo logo-footer">
                                    <a href="index-2.html">
                                        <img src="images/logofoot.png" alt="image">
                                    </a>
                                </div>
                            </div><!-- /.widget-brand -->
                           <p>It’s super simple - Your mining rigs are already set up and running.
As soon as you’ve set up your account, you can start to mine your first coins using our Bitcoin cloud mining service!</p>
                            <p><img src="images/cards.png" /></p>
                        </div><!-- /.col-md-4 -->

                        <div class="col-md-4">
                            <div class="wiget widget-services">
                                <div class="one-half">
                                    <h5 class="widget-title">
                                        POLICY
                                    </h5>
                                    <ul>
                                        <li><a href="terms.php">Terms & Conditions</a></li>
                                        
                                    </ul>
                                </div>
                                <div class="one-half padding_left_73">
                                    <h5 class="widget-title">
                                        SHORT LINK
                                    </h5>
                                    <ul>
                                        <li><a href="how-it-works.php?user=<?php echo $user; ?>">HOW IT WORKS</a></li>
                                        <li><a href="about.php?user=<?php echo $user; ?>">ABOUT US</a></li>
                                        <li><a href="account/index.php">Sign up</a></li>
                                       
                                    </ul>
                                </div>
                            </div><!-- /.widget-services -->
                        </div><!-- /.col-md-4 -->

                        <div class="col-md-4">
                           <div class="widget widget-subscribe">
                               <h5 class="widget-title">
                                  Contact
                               </h5>
                               
                               <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d2483.9643070527623!2d-0.1439769842304674!3d51.49552247963327!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x48760520699914a3%3A0x5cd003928ff56827!2s302%20Vauxhall%20Bridge%20Rd%2C%20Westminster%2C%20London%2C%20UK!5e0!3m2!1sen!2sng!4v1616493487737!5m2!1sen!2sng" width="100%" height="200" style="border:0;" allowfullscreen="" loading="lazy"></iframe>
                               
                                <p>302 Vauxhall Bridge Road, London, England, SW1V 1AA</p>
                               
                                <p>
                                    Email: support@onegenesisinc.com<br /> Phone: +44-7003200284
                                </p>
                               
                           </div>
                        </div><!-- /.col-md-4 -->
                    </div><!-- /.row -->
                </div><!-- /.container -->
            </div><!-- /.footer-widgets -->
        </footer><!-- /.footer -->

        <div class="footer-bottom">
            <div class="container">
                <div class="row">
                    <div class="col-md-12">
                        <p class="copyright text-center">&copy; Copyright 2013-2021, All rights reserved. Genesis-Mining</p>
                    </div>
                </div>
            </div>
        </div><!-- /.footer-bottom -->

        <!-- Go Top -->
        <a class="go-top">
            <i class="fa fa-chevron-up"></i>
        </a>  

    </div>

    


    <!-- Javascript -->
    <script src="javascript/jquery.min.js"></script>
    <script src="javascript/tether.min.js"></script>
    <script src="javascript/bootstrap.min.js"></script>
    <script src="javascript/jquery.easing.js"></script>    
    <script src="javascript/parallax.js"></script>
    <script src="javascript/owl.carousel.js"></script>
    <script src="javascript/jquery-countTo.js"></script>
    <script src="javascript/jquery-waypoints.js"></script>
    <script src="javascript/jquery-validate.js"></script>
    <script src="javascript/jquery.cookie.js"></script>
    <script src="javascript/plotly-latest.min.js"></script>
    <script src="javascript/jquery.easeScroll.js"></script>
    <script src="javascript/gmap3.min.js"></script>
    <script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyDLjIsk1A1SP8UsfNf2r4VXPinzvnIsnN4&amp;region=GB"></script>
    <script src="javascript/main.js"></script>

    <!-- Revolution Slider -->
    <script src="revolution/js/jquery.themepunch.tools.min.js"></script>
    <script src="revolution/js/jquery.themepunch.revolution.min.js"></script>
    <script src="revolution/js/slider.js"></script>
    
    
     <!-- All Plugins js -->
    <script>
    (function(e){"use strict";e.fn.counterUp=function(t){var n=e.extend({time:400,delay:10},t);return this.each(function(){var t=e(this),r=n,i=function(){var e=[],n=r.time/r.delay,i=t.text(),s=/[0-9]+,[0-9]+/.test(i);i=i.replace(/,/g,"");var o=/^[0-9]+$/.test(i),u=/^[0-9]+\.[0-9]+$/.test(i),a=u?(i.split(".")[1]||[]).length:0;for(var f=n;f>=1;f--){var l=parseInt(i/n*f);u&&(l=parseFloat(i/n*f).toFixed(a));if(s)while(/(\d+)(\d{3})/.test(l.toString()))l=l.toString().replace(/(\d+)(\d{3})/,"$1,$2");e.unshift(l)}t.data("counterup-nums",e);t.text("0");var c=function(){t.text(t.data("counterup-nums").shift());if(t.data("counterup-nums").length)setTimeout(t.data("counterup-func"),r.delay);else{delete t.data("counterup-nums");t.data("counterup-nums",null);t.data("counterup-func",null)}};t.data("counterup-func",c);setTimeout(t.data("counterup-func"),r.delay)};t.waypoint(i,{offset:"100%",triggerOnce:!0})})}})(jQuery);
    </script>

    <!-- script js -->
    <script src="js2/script.js"></script>

    <!-- SLIDER REVOLUTION 5.0 EXTENSIONS  (Load Extensions only on Local File Systems !  The following part can be removed on Server for On Demand Loading) -->    
    <script src="revolution/js/extensions/revolution.extension.actions.min.js"></script>
    <script src="revolution/js/extensions/revolution.extension.carousel.min.js"></script>
    <script src="revolution/js/extensions/revolution.extension.kenburn.min.js"></script>
    <script src="revolution/js/extensions/revolution.extension.layeranimation.min.js"></script>
    <script src="revolution/js/extensions/revolution.extension.migration.min.js"></script>
    <script src="revolution/js/extensions/revolution.extension.navigation.min.js"></script>
    <script src="revolution/js/extensions/revolution.extension.parallax.min.js"></script>
    <script src="revolution/js/extensions/revolution.extension.slideanims.min.js"></script>
</body> 

</html>     