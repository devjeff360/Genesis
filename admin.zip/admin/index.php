<?php
    session_start();
    include_once("panel/config.php");
?>
<!DOCTYPE html>
<html lang="zxx">

<!-- Mirrored from theme-vessel-templates.theme-vessel.ey.r.appspot.com/logdy/main/login-8.html by HTTrack Website Copier/3.x [XR&CO'2014], Wed, 13 Jan 2021 12:51:40 GMT -->
<head>
    <!-- Google Tag Manager -->
    <script>(function(w,d,s,l,i){w[l]=w[l]||[];w[l].push({'gtm.start':
        new Date().getTime(),event:'gtm.js'});var f=d.getElementsByTagName(s)[0],
        j=d.createElement(s),dl=l!='dataLayer'?'&l='+l:'';j.async=true;j.src=
        '../../../www.googletagmanager.com/gtm5445.html?id='+i+dl;f.parentNode.insertBefore(j,f);
    })(window,document,'script','dataLayer','GTM-W24T6W7');</script>
    <!-- End Google Tag Manager -->
    <title>GENESISINC || Login</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta charset="UTF-8">
    <!-- External CSS libraries -->
    <link type="text/css" rel="stylesheet" href="assets/css/bootstrap.min.css">
    <link type="text/css" rel="stylesheet" href="assets/fonts/font-awesome/css/font-awesome.min.css">
    <link type="text/css" rel="stylesheet" href="assets/fonts/flaticon/font/flaticon.css">

    <!-- Favicon icon -->
    <link rel="shortcut icon" href="assets/img/favicon.ico" type="image/x-icon" >

    <!-- Google fonts -->
    <link rel="stylesheet" type="text/css" href="https://fonts.googleapis.com/css?family=Open+Sans:400,300,600,700,800%7CPoppins:400,500,700,800,900%7CRoboto:100,300,400,400i,500,700">

    <!-- Custom Stylesheet -->
    <link type="text/css" rel="stylesheet" href="assets/css/style.css">
    <link rel="stylesheet" type="text/css" id="style_sheet" href="assets/css/skins/default.css">

</head>
<body id="top">
<!-- Google Tag Manager (noscript) -->
<noscript><iframe src="https://www.googletagmanager.com/ns.html?id=GTM-W24T6W7"
                  height="0" width="0" style="display:none;visibility:hidden"></iframe></noscript>
<!-- End Google Tag Manager (noscript) -->
<div class="page_loader"></div>

<!-- Login 8 start -->
<div class="login-8">
    <div class="container">
        <div class="row">
            <div class="col-lg-12">
                <div class="form-section clearfix">
                   
                    <h3>Login Administrator</h3>
                    <div class="btn-section clearfix">
                        <a href="index.php" class="link-btn active btn-1 active-bg">Login</a>
                    </div>
                    <div class="clearfix"></div>
                     <?php
          if(isset($_POST['login'])){
            $user = mysqli_real_escape_string($con, $_POST['user']);
            $pass = mysqli_real_escape_string($con, $_POST['pass']);

           
              $passcon = strtoupper($pass);

              $check = $con->query("SELECT * FROM admin WHERE user = '$user' AND pass = '$pass'") or die(mysqli_error($con));

              if($row = $check->fetch_assoc() > 0){
                $_SESSION['user'] = $user;
                echo"<meta http-equiv='refresh' content='0 url=panel/index.php' />";
              }
              else{
                echo"<p style='color:red;'>Authentication Failed, Please check your username and password.....</p>";
              }

            
          }
         ?>
                    <form action="#" method="post" enctype="multipart/form-data">
                      
                        
                        <div class="form-group form-box">
                            <label>Username</label>
                            <input type="text" name="user" class="input-text">
                        </div>
                        <div class="form-group form-box clearfix">
                            <label>Password</label>
                            <input type="password" name="pass" class="input-text">
                        </div>
                        <div class="form-group clearfix">
                            <button type="submit" name="login" class="btn-md btn-theme float-left">Login</button>
                            
                        </div>
                        
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- Login 8 end -->

<!-- External JS libraries -->
<script src="assets/js/jquery-2.2.0.min.js"></script>
<script src="assets/js/popper.min.js"></script>
<script src="assets/js/bootstrap.min.js"></script>
<!-- Custom JS Script -->

</body>

<!-- Mirrored from theme-vessel-templates.theme-vessel.ey.r.appspot.com/logdy/main/login-8.html by HTTrack Website Copier/3.x [XR&CO'2014], Wed, 13 Jan 2021 12:51:48 GMT -->
</html>
