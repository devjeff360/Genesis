<?php session_start();

include_once("config.php");

  $user = $_SESSION["user"];
   if(!isset($_SESSION['user'])) {
 echo "<meta  http-equiv=\"refresh\" content=\"0, url=https://GFXtraders.com/register.php?Login=Error\" />";
  
  }
else {
    
$email = $_GET['email'];
$amt = $_GET['amt'];
$roi = $_GET['roi'];
$id = $_GET['id'];
 
    $getbal = $con->query("SELECT * FROM bal WHERE email = '$email'") or die(mysqli_error($con));
    
        while($gb = $getbal->fetch_assoc()){
            $balance = $gb['balance'];
        }
    
    $nb = $roi - $amt;
    $newbal = $balance + $nb;
    
    $update = $con->query("UPDATE bal SET balance = '$newbal' WHERE email = '$email'") or die(mysqli_error($con));
    $update2 = $con->query("DELETE FROM invest WHERE id = '$id'") or die(mysqli_error($con));
    
    if($update == TRUE){
        echo"<script>alert('Investment cancelled and deleted');</script>";
            echo"<meta http-equiv='refresh' content='0 url=index.php' />";
    }else{
        echo"<script>alert('An error occured');</script>";
            echo"<meta http-equiv='refresh' content='0 url=index.php' />";
    }
 
}

  ?>