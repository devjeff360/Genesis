<?php session_start();

include_once("config.php");

  $user = $_SESSION["user"];
   if(!isset($_SESSION['user'])) {
 echo "<meta  http-equiv=\"refresh\" content=\"0, url=https://onegenesisinc.com/account/index.php?Login=Error\" />";
  
  }
else {
    
    if(isset($_POST['confirm'])){
        
$id = $_POST['id'];
$username = $_POST['user'];
$fn = $_POST['fn'];
$amt = $_POST['amt'];
$email = $_POST['email'];
$acctype = $_POST['acctype'];
$det = $_POST['det'];
$amt = $_POST['amt'];
$hash = $_POST['hash'];
        
    
    
  
    
    $update = $con->query("UPDATE withdraw SET status = 'SUCCESSFUL' WHERE id = '$id'") or die(mysqli_error($con));
    
    if($update == TRUE){
        echo"<script>alert('DONE');</script>";
            echo"<meta http-equiv='refresh' content='0 url=https://onegenesisinc.com/account/src/gappmail.php?to=$email&amt=$amt&acctype=$acctype&det=$det&hash=$hash&user=$user&fn=$fn' />";
    }else{
        echo"<script>alert('An error occured');</script>";
            echo"<meta http-equiv='refresh' content='0 url=withdraw.php' />";
    }
    }
}

  ?>