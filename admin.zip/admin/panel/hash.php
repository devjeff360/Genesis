<?php session_start();

include_once("config.php");

  $user = $_SESSION["user"];
   if(!isset($_SESSION['user'])) {
 echo "<meta  http-equiv=\"refresh\" content=\"0, url=https://onegenesisinc.com/account/index.php?Login=Error\" />";
  
  }
else {
    
 $id = $_GET['id'];
$username = $_GET['user'];
$email = $_GET['email'];
$acctype = $_GET['acctype'];
$det = $_GET['det'];
$amt = $_GET['amt'];
    
    $getname = $con->query("SELECT * FROM reg_users WHERE user = '$username'") or die(mysqli_error($con));
    
    while($row = $getname->fetch_assoc()){
                      $firstname = $row['firstname'];
                      $lastname = $row['lastname'];
    }
 
}

  ?><!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>Admin</title>
	<link href="css/bootstrap.min.css" rel="stylesheet">
	<link href="css/fontawesome-free/css/all.css" rel="stylesheet">
	<link href="css/datepicker3.css" rel="stylesheet">
	<link href="css/styles.css" rel="stylesheet">
	
	<!--Custom Font-->
	<link href="https://fonts.googleapis.com/css?family=Montserrat:300,300i,400,400i,500,500i,600,600i,700,700i" rel="stylesheet">
	<!--[if lt IE 9]>
	<script src="js/html5shiv.js"></script>
	<script src="js/respond.min.js"></script>
	<![endif]-->
</head>
<body>
	<nav class="navbar navbar-custom navbar-fixed-top" role="navigation">
		<div class="container-fluid">
			<div class="navbar-header">
				<button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#sidebar-collapse"><span class="sr-only">Toggle navigation</span>
					<span class="icon-bar"></span>
					<span class="icon-bar"></span>
					<span class="icon-bar"></span></button>
				<a class="navbar-brand" href="#">Admin Dashboard</a>
			</div>
		</div><!-- /.container-fluid -->
	</nav>
	<?php
	include_once "sidebar.php";
	?>
		
	<div class="col-sm-9 col-sm-offset-3 col-lg-10 col-lg-offset-2 main">
		<div class="row">
			<ol class="breadcrumb">
				<li><a href="#">
					<em class="fa fa-home"></em>
				</a></li>
				<li class="active">Dashboard</li>
			</ol>
		</div><!--/.row-->
		
		<div class="row">
			<div class="col-lg-12">
				<h1 class="page-header">Input Transaction Hash</h1>
			</div>
		</div><!--/.row-->
		
		<div class="panel panel-container table-responsive">
     
            <form action="appfund.php" method="post" enctype="multipart/form-data" style="width:96%; margin-left:2%;">
                <div class="row">
                     <div class="col-md-6"><label>Fullname</label>
                        <input type="text" name="fn" class="form-control" value="<?php echo ucwords("$firstname $lastname"); ?>" readonly style="margin-bottom:10px;" />
                    </div>
                    <div class="col-md-6"><label>Username</label>
                        <input type="text" name="user" class="form-control" value="<?php echo $username; ?>" readonly style="margin-bottom:10px;" />
                    </div>
                    <div class="col-md-6">
                    <label>Email Address</label>
                        <input type="text" name="email" class="form-control" value="<?php echo $email; ?>" readonly style="margin-bottom:10px;" />
                    </div>
                </div>
                
                 <div class="row">
                    <div class="col-md-6"><label>Account Type</label>
                        <input type="text" name="acctype" class="form-control" value="<?php echo $acctype; ?>" readonly style="margin-bottom:10px;" />
                    </div>
                    <div class="col-md-6">
                    <label>Address</label>
                        <input type="text" name="det" class="form-control" readonly value="<?php echo $det; ?>" readonly style="margin-bottom:10px;" />
                    </div>
                </div>
                
                <div class="row">
                    <div class="col-md-6"><label>Amount</label>
                        <input type="text" name="amt" class="form-control" value="<?php echo $amt; ?>" readonly style="margin-bottom:10px;" />
                    </div>
                    <div class="col-md-6">
                    <label>Transaction hash</label>
                        <input type="text" name="hash" class="form-control" value="" required style="margin-bottom:10px'" />
                    </div>
                </div>
               
                        <input type="text" name="id" class="form-control" value="<?php echo $id; ?>" style="margin-bottom:10px; display:none;" />
                  
                
               <div class="row">
                    <div class="col-md-6"><button class="btn btn-success" name="confirm" type="submit">CONFIRM</button></div>
                </div> 
                <br />
            
            </form>
                
       </div>		
		
		
	</div>	<!--/.main-->
	
	<script src="js/jquery-1.11.1.min.js"></script>
	<script src="js/bootstrap.min.js"></script>
	<script src="js/chart.min.js"></script>
	<script src="js/chart-data.js"></script>
	<script src="js/easypiechart.js"></script>
	<script src="js/easypiechart-data.js"></script>
	<script src="js/bootstrap-datepicker.js"></script>
	<script src="js/custom.js"></script>
	<script>
		window.onload = function () {
	var chart1 = document.getElementById("line-chart").getContext("2d");
	window.myLine = new Chart(chart1).Line(lineChartData, {
	responsive: true,
	scaleLineColor: "rgba(0,0,0,.2)",
	scaleGridLineColor: "rgba(0,0,0,.05)",
	scaleFontColor: "#c5c7cc"
	});
};
	</script>
		
</body>
</html>