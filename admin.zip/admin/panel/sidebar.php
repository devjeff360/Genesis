
<div id="sidebar-collapse" class="col-sm-3 col-lg-2 sidebar">
		<div class="profile-sidebar">
			<div class="profile-usertitle">
				<div class="profile-usertitle-name">Administrator</div>
				<div class="profile-usertitle-status"><span class="indicator label-success"></span>Online</div>
			</div>
			<div class="clear"></div>
		</div>
		<div class="divider"></div>
		<ul class="nav menu">
			<li class="active"><a href="index.php"><em class="fa fa-tachometer-alt">&nbsp;</em> Dashboard</a></li>
			<li><a href="allinv.php"><em class="fa fa-user">&nbsp;</em> All Active Investors</a></li>
			<li><a href="suspended.php"><em class="fa fa-user">&nbsp;</em> All Suspended Investors</a></li>
			<li><a href="network.php"><em class="fa fa-user">&nbsp;</em> NETWORKS</a></li>
			<li><a href="allwal.php"><em class="fa fa-wallet">&nbsp;</em> All Wallets</a></li>
			<li><a href="alltrans.php"><em class="fa fa-toggle-off">&nbsp;</em> Transactions</a></li>
			<li><a href="withdraw.php"><em class="fa fa-clone">&nbsp;</em> Withdrawals</a></li>
			<li><a href="re-wallet.php"><em class="fa fa-clone">&nbsp;</em> Receiving Wallets</a></li>
			<li class="parent "><a data-toggle="collapse" href="#sub-item-1">
				<em class="fa fa-navicon">&nbsp;</em> Active Packages <span data-toggle="collapse" href="#sub-item-1" class="icon pull-right"><em class="fa fa-plus"></em></span>
				</a>
<ul class="children collapse" id="sub-item-1">
					<li><a href="active.php?pack=Starter">
						<span class="fa fa-arrow-right">&nbsp;</span> Starter
					</a></li> 
					<li><a href="active.php?pack=Bronze">
						<span class="fa fa-arrow-right">&nbsp;</span> Bronze
					</a></li>
					<li><a href="active.php?pack=Silver">
						<span class="fa fa-arrow-right">&nbsp;</span> Silver
					</a></li>
                    <li><a href="active.php?pack=Diamond">
						<span class="fa fa-arrow-right">&nbsp;</span> Diamond
					</a></li>
                 
				</ul>
			</li>
			<li class="parent "><a data-toggle="collapse" href="#sub-item-2">
				<em class="fa fa-navicon">&nbsp;</em> Investment History <span data-toggle="collapse" href="#sub-item-2" class="icon pull-right"><em class="fa fa-plus"></em></span>
				</a>
				<ul class="children collapse" id="sub-item-2">
					<li><a href="history.php?pack=Starter">
						<span class="fa fa-arrow-right">&nbsp;</span> Starter
					</a></li> 
					<li><a href="history.php?pack=Bronze">
						<span class="fa fa-arrow-right">&nbsp;</span> Bronze
					</a></li>
					<li><a href="history.php?pack=Silver">
						<span class="fa fa-arrow-right">&nbsp;</span> Silver
					</a></li>
                    <li><a href="history.php?pack=Diamond">
						<span class="fa fa-arrow-right">&nbsp;</span> Diamond
					</a></li>
				</ul>
			</li>
			<li><a href="#"><em class="fa fa-bell">&nbsp;</em> Notification</a></li>
			<li><a href="https://onegenesisinc.com/account/index.php?Login=Error"><em class="fa fa-power-off">&nbsp;</em> Logout</a></li>
		</ul>
	</div><!--/.sidebar-->