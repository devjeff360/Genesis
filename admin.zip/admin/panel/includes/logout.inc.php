<?php

include_once "dbh.php";
session_start();
if(session_destroy()){
    header("Location: /New Admin/index.php?logout=true");
}