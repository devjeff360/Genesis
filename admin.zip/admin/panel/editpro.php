<?php session_start();

include_once("config.php");

  $user = $_SESSION["user"];
   if(!isset($_SESSION['user'])) {
 echo "<meta  http-equiv=\"refresh\" content=\"0, url=https://onegenesisinc.com/account/index.php?Login=Error\" />";
  
  }
else {
    
    if(isset($_POST['update'])){
        $fname = $_POST['fname'];
        $lname = $_POST['lname'];
        $user = $_POST['user'];
        $email = $_POST['email'];
        $phone = $_POST['phone'];
        $password = $_POST['password'];
        $acctype = $_POST['acctype'];
        $det = $_POST['det'];
        
        $update = $con->query("UPDATE reg_users SET firstname = '$fname', lastname = '$lname', user = '$user', email = '$email', phone = '$phone', password = '$password', acctype = '$acctype', det = '$det' WHERE email = '$email'") or die(mysqli_error($con));
        
        if($update == TRUE){
            echo"<script>alert('Updated');</script>";
            echo"<meta http-equiv='refresh' content='0 url=#' />";
        }
    }
    
    if(isset($_GET['did'])){
        
        $did = $_GET['did'];
        
        $delete = $con->query("DELETE FROM reg_users WHERE email = '$did'") or die(mysqli_error($con));
        $delete2 = $con->query("DELETE FROM bal WHERE email = '$did'") or die(mysqli_error($con));
        
        if($delete && $delete2 == TRUE){
            echo"<script>alert('Deleted');</script>";
            echo"<meta http-equiv='refresh' content='0 url=#' />";
        }
        
        
    }
 
}

  ?><!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>Admin</title>
	<link href="css/bootstrap.min.css" rel="stylesheet">
	<link href="css/fontawesome-free/css/all.css" rel="stylesheet">
	<link href="css/datepicker3.css" rel="stylesheet">
	<link href="css/styles.css" rel="stylesheet">
	
	<!--Custom Font-->
	<link href="https://fonts.googleapis.com/css?family=Montserrat:300,300i,400,400i,500,500i,600,600i,700,700i" rel="stylesheet">
	<!--[if lt IE 9]>
	<script src="js/html5shiv.js"></script>
	<script src="js/respond.min.js"></script>
	<![endif]-->
</head>
<body>
	<nav class="navbar navbar-custom navbar-fixed-top" role="navigation">
		<div class="container-fluid">
			<div class="navbar-header">
				<button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#sidebar-collapse"><span class="sr-only">Toggle navigation</span>
					<span class="icon-bar"></span>
					<span class="icon-bar"></span>
					<span class="icon-bar"></span></button>
				<a class="navbar-brand" href="#">Admin Dashboard</a>
			</div>
		</div><!-- /.container-fluid -->
	</nav>
	<?php
	include_once "sidebar.php";
	?>
		
	<div class="col-sm-9 col-sm-offset-3 col-lg-10 col-lg-offset-2 main">
		<div class="row">
			<ol class="breadcrumb">
				<li><a href="#">
					<em class="fa fa-home"></em>
				</a></li>
				<li class="active">Dashboard</li>
			</ol>
		</div><!--/.row-->
		
		<div class="row">
			<div class="col-lg-12">
				<h1 class="page-header">Edit Profile</h1>
			</div>
		</div><!--/.row-->
		
		<div class="panel panel-container table-responsive">
            
         
                
                <?php 
            $id = $_GET['id'];
            
                    $getdata = $con->query("SELECT * FROM reg_users WHERE id = '$id'") or die(mysqli_error($con));
                
                    while($gd = $getdata->fetch_assoc()){
                        $fname = $gd['firstname'];
                        $lname = $gd['lastname'];
                        $email = $gd['email'];
                        $user = $gd['user'];
                        $phone = $gd['phone'];
                        $password = $gd['password'];
                        $refcode = $gd['refcode'];
                        $acctype = $gd['acctype'];
                        $det = $gd['det'];
                        
                    }
                ?>
            
            <form action="#" method="post" enctype="multipart/form-data" style="width:96%; margin-left:2%;">
                <div class="row">
                    <div class="col-md-6"><label>Firstname</label>
                        <input type="text" name="fname" class="form-control" value="<?php echo $fname; ?>" style="margin-bottom:10px'" />
                    </div>
                    <div class="col-md-6">
                    <label>Lastname</label>
                        <input type="text" name="lname" class="form-control" value="<?php echo $lname; ?>" style="margin-bottom:10px'" />
                    </div>
                </div>
                
                 <div class="row">
                    <div class="col-md-6"><label>Username</label>
                        <input type="text" name="user" class="form-control" value="<?php echo $user; ?>" style="margin-bottom:10px'" />
                    </div>
                    <div class="col-md-6">
                    <label>Email Address</label>
                        <input type="text" name="email" class="form-control" readonly value="<?php echo $email; ?>" style="margin-bottom:10px'" />
                    </div>
                </div>
                
                <div class="row">
                    <div class="col-md-6"><label>Phone Number</label>
                        <input type="text" name="phone" class="form-control" value="<?php echo $phone; ?>" style="margin-bottom:10px'" />
                    </div>
                    <div class="col-md-6">
                    <label>Password</label>
                        <input type="text" name="password" class="form-control" value="<?php echo $password; ?>" style="margin-bottom:10px'" />
                    </div>
                </div>
                <p><center><b><i>Payment details</i></b></center></p>
                
                <div class="row">
                    <div class="col-md-6"><label>Account type</label>
                       <select name="acctype" class="form-control">
                            <option value="<?php if($acctype){ echo $acctype; }else{ echo"-- SELECT TYPE --"; } ?>"><?php if($acctype){ echo $acctype; }else{ echo"-- SELECT TYPE --"; } ?></option>
                            <option value="Bitcoin">Bitcoin</option>
                            <option value="Etherum">Ethereum</option>
                            <option value="Litecoin">Litecoin</option>
                            <option value="Trons">Trons</option>
                            <option value="Bitcoin cash">Bitcoin cash</option>
                            <option value="Paypal" disabled>Paypal (Coming soon)</option>
                            <option value="Cashapp" disabled>Cashapp (Coming soon)</option>
                        </select>
                    </div>
                    <div class="col-md-6">
                    <label>Wallet Address</label>
                        <input type="text" name="det" class="form-control" value="<?php echo $det; ?>" style="margin-bottom:10px'" />
                    </div>
                </div>
                
               <div class="row">
                    <div class="col-md-6"><button class="btn btn-success" name="update" type="submit">UPDATE</button></div>
                    <div class="col-md-6"><a href="editpro.php?did=<?php echo $email; ?>" class="btn btn-danger">DELETE ACCOUNT</a></div>
                </div> 
                <br />
            
            </form>
                
<p class="alert alert-danger">Please sure you want to delete this account before you hit the delete button, account deleted can not be retreived</p>
        </div>		
		
		
	</div>	<!--/.main-->
	
	<script src="js/jquery-1.11.1.min.js"></script>
	<script src="js/bootstrap.min.js"></script>
	<script src="js/chart.min.js"></script>
	<script src="js/chart-data.js"></script>
	<script src="js/easypiechart.js"></script>
	<script src="js/easypiechart-data.js"></script>
	<script src="js/bootstrap-datepicker.js"></script>
	<script src="js/custom.js"></script>
	<script>
		window.onload = function () {
	var chart1 = document.getElementById("line-chart").getContext("2d");
	window.myLine = new Chart(chart1).Line(lineChartData, {
	responsive: true,
	scaleLineColor: "rgba(0,0,0,.2)",
	scaleGridLineColor: "rgba(0,0,0,.05)",
	scaleFontColor: "#c5c7cc"
	});
};
	</script>
		
</body>
</html>