<?php

   $server = "localhost";
$dbUsername = "root";
$dbPassword = "";
$dbName = "GFX";

$con = new mysqli($server, $dbUsername, $dbPassword, $dbName) or die("Connection Failed %s\n". $con -> error);


?>