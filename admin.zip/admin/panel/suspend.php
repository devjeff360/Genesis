<?php session_start();

include_once("config.php");

  $user = $_SESSION["user"];
   if(!isset($_SESSION['user'])) {
 echo "<meta  http-equiv=\"refresh\" content=\"0, url=https://onegenesisinc.com/account/index.php?Login=Error\" />";
  
  }
else {
   
$id = $_GET['id'];
    
    $update = $con->query("UPDATE reg_users SET status = 'SUSPENDED' WHERE id = '$id'") or die(mysqli_error($con));
    
    if($update == TRUE){
        echo"<script>alert('DONE');</script>";
            echo"<meta http-equiv='refresh' content='0 url=suspended.php' />";
    }else{
        echo"<script>alert('An error occured');</script>";
            echo"<meta http-equiv='refresh' content='0 url=allinv.php' />";
    }
    }


  ?>