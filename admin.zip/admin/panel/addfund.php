<?php session_start();

include_once("config.php");

  $user = $_SESSION["user"];
   if(!isset($_SESSION['user'])) {
 echo "<meta  http-equiv=\"refresh\" content=\"0, url=https://onegenesisinc.com/account/index.php?Login=Error\" />";
  
  }
else {
    
$email = $_GET['email'];
$amt = $_GET['amt'];
$id = $_GET['id'];
 
    $getbal = $con->query("SELECT * FROM bal WHERE email = '$email'") or die(mysqli_error($con));
    
        while($gb = $getbal->fetch_assoc()){
            $balance = $gb['balance'];
        }
    
    $newbal = $amt + $balance;
    
    $update = $con->query("UPDATE bal SET balance = '$newbal' WHERE email = '$email'") or die(mysqli_error($con));
    $update2 = $con->query("UPDATE transhist SET status = 'SUCCESSFUL' WHERE id = '$id'") or die(mysqli_error($con));
    
    if($update == TRUE){
        echo"<script>alert('Account Credited');</script>";
            echo"<meta http-equiv='refresh' content='0 url=alltrans.php' />";
    }else{
        echo"<script>alert('An error occured');</script>";
            echo"<meta http-equiv='refresh' content='0 url=alltrans.php' />";
    }
 
}

  ?>