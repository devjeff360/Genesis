<?php

$fname = $_GET['fname'];
$lname = $_GET['lname'];
$to = $_GET['smail'];
$user = $_GET['user'];
$fn = "$fname $lname";



 
 if($smail){
        echo"<meta http-equiv='refresh' content='3 url=index.php' />";
    }else{
     echo"<meta http-equiv='refresh' content='3 url=index.php' />";
       
    }

?>

<!DOCTYPE html>
    <html>
        <head>
            <title>PROCESS</title>
        </head>
        
        <body>

            
            <h1>Please wait... redirecting in 5 seconds</h1>
            <div style="display:none;">
               <form id="form">
  <div class="field">
    <label for="topic">topic</label>
    <input type="text" name="topic" id="topic" value="NEW DOWNLINE UNDER YOU">
  </div>
  <div class="field">
    <label for="message">message</label>
    <input type="text" name="message" id="message" value="<?php echo "Hello, This is to notify you that A new account has been successfully created, using your referral link

User: $user
Name: $fn

you are liable to get your 7% referral bonus immediately user $user make first investment.
           "; ?>">
  </div>
  <div class="field">
    <label for="send_to">send_to</label>
    <input type="text" name="send_to" id="send_to" value="<?php echo $to; ?>">
  </div>

  <input type="submit" id="button" value="Send Email" >
</form>

            </div>
            
         
<script type="text/javascript"
  src="https://cdn.jsdelivr.net/npm/@emailjs/browser@3/dist/email.min.js"></script>

<script type="text/javascript">
  emailjs.init('3KpB8QIWCUyVcQsjB')
</script>
            
            
            <script>

window.onload = function(){
  document.getElementById('button').click();
}
    
                const btn = document.getElementById('button');

document.getElementById('form')
 .addEventListener('submit', function(event) {
   event.preventDefault();

   btn.value = 'Sending...';

   const serviceID = 'default_service';
   const templateID = 'template_05ijb9b';

   emailjs.sendForm(serviceID, templateID, this)
    .then(() => {
      btn.value = 'Send Email';
      //alert('Sent!');
    }, (err) => {
      btn.value = 'Send Email';
      //alert(JSON.stringify(err));
    });
});
            
            </script>
        </body>

    </html>
 

