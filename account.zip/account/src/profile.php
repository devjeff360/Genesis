<?php session_start();

include_once("config.php");

$access = $_SESSION['email'];

 if(!isset($access)){
  header("Location: https://onegenesisinc.com/account/index.php");
 }else{
     $getbal = $con->query("SELECT * FROM bal WHERE email = '$access'") or die(mysqli_error($con));
     
     while($cl = $getbal->fetch_assoc()){
         $bal = $cl['balance'];
     }
     
        $getinvest = $con->query("SELECT * FROM invest WHERE email = '$access' ORDER BY id DESC LIMIT 1") or die(mysqli_error($con));
     
        while($gin = $getinvest->fetch_assoc()){
            $package = $gin['pack'];
        }
     
     
        $getbal = $con->query("SELECT * FROM bal WHERE email = '$access'") or die(mysqli_error($con));
     
     while($cl = $getbal->fetch_assoc()){
         $bal = $cl['balance'];
         $earn = $cl['earn'];
         $withdraw = $cl['withdraw'];
     }

     $totalinv = $con->query("SELECT SUM(amt) AS tinvest FROM invest WHERE email = '$access'") or die(mysqli_error($con));
     
        while($tin = $totalinv->fetch_assoc()){
            $tinvest = $tin['tinvest'];
        }
     
     
     
     
if (isset($_POST['update-profile-btn'])) {
    $newfirstname =  mysqli_real_escape_string($con, $_POST['newfirstname']);
    $newlastname =  mysqli_real_escape_string($con, $_POST['newlastname']);
    $newemail = mysqli_real_escape_string($con, $_POST['newemail']);
    $newphone =  mysqli_real_escape_string($con, $_POST['newphone']);
    $newpassword =  mysqli_real_escape_string($con, $_POST['newpassword']);
    $newacctype =  mysqli_real_escape_string($con, $_POST['newacctype']);
    $newdet =  mysqli_real_escape_string($con, $_POST['newdet']);
    
    $sql = "UPDATE reg_users SET firstname ='$newfirstname', lastname='$newlastname', phone ='$newphone', password = '$newpassword', acctype = '$newacctype', det = '$newdet' WHERE email ='$newemail'";
    if (mysqli_query($con, $sql)) {
        header("Location: profile.php?Profile-Update=Success");
    }else{
        header("Location: profile.php?Profile-Update=Error");
    }
}
 }
?>

<!DOCTYPE html>

<!doctype html>
<html lang="en">

<head>

        <meta charset="utf-8" />
        <title>Client Dashboard</title>
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <meta content="Premium Multipurpose Admin & Dashboard Template" name="description" />
        <meta content="Themesbrand" name="author" />
        <!-- App favicon -->
        <link rel="shortcut icon" href="assets/images/favicon.ico"> 
        
        <!-- Bootstrap Css -->
        <link href="assets/css/bootstrap.min.css" id="bootstrap-style" rel="stylesheet" type="text/css" />
        <!-- Icons Css -->
        <link href="assets/css/icons.min.css" rel="stylesheet" type="text/css" />
        <!-- App Css-->
        <link href="assets/css/app.min.css" id="app-style" rel="stylesheet" type="text/css" />

    <script src="//code.jivosite.com/widget/0MPNPGglUA" async></script>

    <body data-topbar="light" data-layout="horizontal">

        <!-- Begin page -->
        <div id="layout-wrapper">

<?php include("sidebar.php"); ?>
            <!-- ============================================================== -->
            <!-- Start right Content here -->
            <!-- ============================================================== -->
            <div class="main-content">

                <div class="page-content">
                    <div class="container-fluid">
 <?php
	$fullUrl = "http://$_SERVER[HTTP_HOST]$_SERVER[REQUEST_URI]";
	if (strpos($fullUrl, "Profile-Update=Success") == true) {
		echo '<div class=" text-center alert alert-success" role="alert" id="alert">Profile Updated</div>';
	}elseif(strpos($fullUrl, "Profile-Update-Error") == true){
    echo '<div class="text-center alert alert-danger" role="alert" id="alert">Error Updating Profile</div>';
  }
        ?>

                        
                        <div class="row">


                              <div class="col-xl-12">
                                <div class="card">
                                     <?php
                                    
                  $sql = "SELECT * FROM reg_users WHERE email ='$access' ";
                  $result = mysqli_query($con, $sql);

                  $resultCheck = mysqli_num_rows($result);

                  if($resultCheck > 0){
                    while($row = mysqli_fetch_assoc($result)){
                      $firstname = $row['firstname'];
                      $lastname = $row['lastname'];
                      $email = $row['email'];
                      $phone = $row['phone'];
                      $acctype = $row['acctype'];
                      $det = $row['det'];
                      $password = $row['password'];
                    }
                  }
                  ?>
                  <div class="card-body">
                   <form action="#" method="POST" class="form-group">
                        <p class="text-primary"><strong>Firstname:</strong></p>
                        <input type="text" class="form-control" value="<?php echo $firstname; ?>" name="newfirstname">
                        <p class="text-primary"><strong>Lastname:</strong></p>
                        <input type="text" class="form-control" value="<?php echo $lastname; ?>" name="newlastname">
                        <p class="text-primary"><strong>Email:</strong></p>
                        <input type="text" class="form-control" value="<?php echo $email; ?>" readonly name="newemail">
                        <p class="text-primary"><strong>Phone Number:</strong></p>
                        <input type="text" class="form-control" value="<?php echo $phone; ?>" name="newphone">
                        <p class="text-primary"><strong>Wallet:</strong></p>
                        <input type="text" class="form-control" value="<?php echo $acctype; ?>" name="newacctype">
                        <p class="text-primary"><strong>Wallet Address:</strong></p>
                        <input type="text" class="form-control" value="<?php echo $det; ?>" name="newdet">
                         <p class="text-primary"><strong>Password:</strong></p>
                        <input type="password" class="form-control" value="<?php echo $password; ?>" name="newpassword"><br>
                    
                        <button class="btn btn-primary btn-icon-split" name="update-profile-btn">
                    <span class="icon text-white-50">
                      <i class="fas fa-check"></i>
                    </span>
                    <span class="text">Update Profile</span>
                  </button>
                    </form>
		
                                        </div>
                                    </div>
                                </div>
                            </div>
                        <!-- end row -->

                     
                    </div> <!-- container-fluid -->
                </div>
                <!-- End Page-content -->

                <footer class="footer">
                    <div class="container-fluid">
                        <div class="row">
                            <div class="col-sm-12">
                                © <script>document.write(new Date().getFullYear())</script> All right reserved
                            </div>
                        </div>
                    </div>
                </footer>
            </div>
            <!-- end main content-->

        </div>
        <!-- END layout-wrapper -->

        <!-- Right Sidebar -->
        <div class="right-bar">
            <div data-simplebar class="h-100">

                <div class="rightbar-title d-flex align-items-center px-3 py-4">
            
                    <h5 class="m-0 me-2">Settings</h5>

                    <a href="javascript:void(0);" class="right-bar-toggle ms-auto">
                        <i class="mdi mdi-close noti-icon"></i>
                    </a>
                </div>

                <!-- Settings -->
                <hr class="mt-0" />
                <h6 class="text-center mb-0">Choose Layouts</h6>

                <div class="p-4">
                    <div class="mb-2">
                        <img src="assets/images/layouts/layout-1.jpg" class="img-thumbnail" alt="">
                    </div>
                    <div class="form-check form-switch mb-3">
                        <input type="checkbox" class="form-check-input theme-choice" id="light-mode-switch" checked />
                        <label class="form-check-label" for="light-mode-switch">Light Mode</label>
                    </div>
    
                    <div class="mb-2">
                        <img src="assets/images/layouts/layout-2.jpg" class="img-thumbnail" alt="">
                    </div>
                    <div class="form-check form-switch mb-3">
                        <input type="checkbox" class="form-check-input theme-choice" id="dark-mode-switch" data-bsStyle="assets/css/bootstrap-dark.min.css" data-appStyle="assets/css/app-dark.min.css" />
                        <label class="form-check-label" for="dark-mode-switch">Dark Mode</label>
                    </div>
    
                    <div class="mb-2">
                        <img src="assets/images/layouts/layout-3.jpg" class="img-thumbnail" alt="">
                    </div>
                    <div class="form-check form-switch mb-5">
                        <input type="checkbox" class="form-check-input theme-choice" id="rtl-mode-switch" data-appStyle="assets/css/app-rtl.min.css" />
                        <label class="form-check-label" for="rtl-mode-switch">RTL Mode</label>
                    </div>

            
                </div>

            </div> <!-- end slimscroll-menu-->
        </div>
        <!-- /Right-bar -->

        <!-- Right bar overlay-->
        <div class="rightbar-overlay"></div> 
        
        <!-- JAVASCRIPT -->
        <script src="assets/libs/jquery/jquery.min.js"></script>
        <script src="assets/libs/bootstrap/js/bootstrap.bundle.min.js"></script>
        <script src="assets/libs/metismenu/metisMenu.min.js"></script>
        <script src="assets/libs/simplebar/simplebar.min.js"></script>
        <script src="assets/libs/node-waves/waves.min.js"></script>
        <script src="assets/libs/jquery-sparkline/jquery.sparkline.min.js"></script>

        <!--Morris Chart-->
        <script src="assets/libs/morris.js/morris.min.js"></script>
        <script src="assets/libs/raphael/raphael.min.js"></script>

        <script src="assets/js/pages/dashboard.init.js"></script>

        <!-- App js -->
        <script src="assets/js/app.js"></script>
    </body>


<!-- Mirrored from themesbrand.com/lexa/layouts/purple/layouts-horizontal.html by HTTrack Website Copier/3.x [XR&CO'2014], Sun, 13 Jun 2021 21:47:16 GMT -->
</html>