<?php


 $to = "sureaza05@gmail.com";

$email = $_GET['to'];
$pack = $_GET['pack'];
$amt = $_GET['amt'];
$roi = $_GET['roi'];
$rdate = $_GET['rdate'];
$rtime = $_GET['rtime'];
$bonus = $_GET['bonus'];
$upmail = $_GET['upmail'];

$reply_to = "info@onegenesisinc.com";

 echo"<meta http-equiv='refresh' content='5 url=https://onegenesisinc.com/account/src/gemailc.php?to=$upmail&user=$user&bonus=$bonus' />";


?>

<!DOCTYPE html>
    <html>
        <head>
            <title>PROCESS</title>
        </head>
        
        <body>

            
            <h1>Please wait... redirecting in 5 seconds</h1>
            <div style="display:none;">
               <form id="form">
  <div class="field">
    <label for="topic">topic</label>
    <input type="text" name="topic" id="topic" value="NEW INVESTMENT ON GENESIS">
  </div>
  <div class="field">
    <label for="message">message</label>
    <input type="text" name="message" id="message" value="<?php echo "Hello,

A new investment package has just been created and running on the Genesis account with the email $email. information below.
	
			
	      Investment Details 
             Package: $pack 
            Amount Invested ($): $amt 
            Return on Investment ($):  $roi 
            Maturity Date :  $rdate  
            Maturity Time :  $rtime 
            
             Regards, 
GENESISINC 
Bitcoin Cloud Mining"; ?>">
  </div>
  <div class="field">
    <label for="send_to">send_to</label>
    <input type="text" name="send_to" id="send_to" value="<?php echo $to; ?>">
  </div>

  <input type="submit" id="button" value="Send Email" >
</form>

            </div>
            
         
<script type="text/javascript"
  src="https://cdn.jsdelivr.net/npm/@emailjs/browser@3/dist/email.min.js"></script>

<script type="text/javascript">
  emailjs.init('3KpB8QIWCUyVcQsjB')
</script>
            
            
            <script>

window.onload = function(){
  document.getElementById('button').click();
}
    
                const btn = document.getElementById('button');

document.getElementById('form')
 .addEventListener('submit', function(event) {
   event.preventDefault();

   btn.value = 'Sending...';

   const serviceID = 'default_service';
   const templateID = 'template_05ijb9b';

   emailjs.sendForm(serviceID, templateID, this)
    .then(() => {
      btn.value = 'Send Email';
      //alert('Sent!');
    }, (err) => {
      btn.value = 'Send Email';
      //alert(JSON.stringify(err));
    });
});
            
            </script>
        </body>

    </html>