<?php session_start();

include_once("config.php");

  $user = $_SESSION["user"];
   if(!isset($_SESSION['user'])) {
 echo "<meta  http-equiv=\"refresh\" content=\"0, url=../Login/adminlogin.php\" />";
  
  }
else {
    
    $getdata = $con->query("SELECT * FROM profile WHERE user = '$user'") or die(mysqli_error($con));
    
        while($gd = $getdata->fetch_assoc()){
            $fname = $gd['fullname'];
            $accno = $gd['accno'];
            $email = $gd['email'];
        }
    
     $getbal = $con->query("SELECT * FROM bal WHERE email = '$email'") or die(mysqli_error($con));
    
        while($gb = $getbal->fetch_assoc()){
            $bal = $gb['balance'];
            $lbal = $gb['loanbal'];
        }
    
     $gettot = $con->query("SELECT SUM(amt) AS tottrans FROM trans WHERE email = '$email'") or die(mysqli_error($con));
    
        while($gt = $gettot->fetch_assoc()){
            $tot = $gt['tottrans'];
        }
    
    
 
}

  ?>

<!doctype html>
<html lang="en">

    
<!-- Mirrored from themesbrand.com/lexa/layouts/purple/layouts-horizontal.html by HTTrack Website Copier/3.x [XR&CO'2014], Sun, 13 Jun 2021 21:47:16 GMT -->
<head>

        <meta charset="utf-8" />
        <title>Client Dashboard</title>
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <meta content="Premium Multipurpose Admin & Dashboard Template" name="description" />
        <meta content="Themesbrand" name="author" />
        <!-- App favicon -->
        <link rel="shortcut icon" href="assets/images/favicon.ico"> 
        
        <!-- Bootstrap Css -->
        <link href="assets/css/bootstrap.min.css" id="bootstrap-style" rel="stylesheet" type="text/css" />
        <!-- Icons Css -->
        <link href="assets/css/icons.min.css" rel="stylesheet" type="text/css" />
        <!-- App Css-->
        <link href="assets/css/app.min.css" id="app-style" rel="stylesheet" type="text/css" />

    <script src="//code.jivosite.com/widget/0MPNPGglUA" async></script>

    <body data-topbar="light" data-layout="horizontal">

        <!-- Begin page -->
        <div id="layout-wrapper">

<?php include("sidebar.php"); ?>
            <!-- ============================================================== -->
            <!-- Start right Content here -->
            <!-- ============================================================== -->
            <div class="main-content">

                <div class="page-content">
                    <div class="container-fluid">

                        <div class="row">
                            <div class="col-xl-3 col-sm-6">
                                <div class="card mini-stat bg-primary">
                                    <div class="card-body mini-stat-img">
                                        <div class="mini-stat-icon">
                                            <i class="mdi mdi-cube-outline float-end"></i>
                                        </div>
                                        <div class="text-white">
                                            <h6 class="text-uppercase mb-3 font-size-16 text-white">Account</h6>
                                            <h2 class="mb-4 text-white"><?php echo ucwords("$accno"); ?></h2>
                                           <span class="ms-2"><?php echo ucwords("$fname"); ?></span>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-xl-3 col-sm-6">
                                <div class="card mini-stat bg-primary">
                                    <div class="card-body mini-stat-img">
                                        <div class="mini-stat-icon">
                                            <i class="mdi mdi-buffer float-end"></i>
                                        </div>
                                        <div class="text-white">
                                            <h6 class="text-uppercase mb-3 font-size-16 text-white">Checking</h6>
                                            <h2 class="mb-4 text-white"><?php echo ucwords("$ $bal"); ?></h2>
                                            <span class="ms-2">Checking Account Balance</span>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-xl-3 col-sm-6">
                                <div class="card mini-stat bg-primary">
                                    <div class="card-body mini-stat-img">
                                        <div class="mini-stat-icon">
                                            <i class="mdi mdi-tag-text-outline float-end"></i>
                                        </div>
                                        <div class="text-white">
                                            <h6 class="text-uppercase mb-3 font-size-16 text-white">Savings</h6>
                                            <h2 class="mb-4 text-white"><?php echo ucwords("$ $lbal"); ?></h2>
                                            <span class="ms-2">Savings Account Balance</span>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-xl-3 col-sm-6">
                                <div class="card mini-stat bg-primary">
                                    <div class="card-body mini-stat-img">
                                        <div class="mini-stat-icon">
                                            <i class="mdi mdi-briefcase-check float-end"></i>
                                        </div>
                                        <div class="text-white">
                                            <h6 class="text-uppercase mb-3 font-size-16 text-white">Net Account Balance</h6>
                                            <h2 class="mb-4 text-white"><?php echo "$".$netbal = $bal + $lbal; ?></h2>
                                            <span class="ms-2">Total Balance Available</span>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <!-- end row -->
                        <p class="alert alert-danger"><marquee>Account Suspended, add Second Beneficiary to activate Spending, Contact Support.</marquee></p>
                        
                        <div class="row">


                              <div class="col-xl-12">
                                <div class="card">
                                    <div class="card-body">
                                        <h4 class="card-title mb-4">Apply For A Loan</h4>

                                        <div class="table-responsive">
                                           <center><h3>PLEASE ACTIVATE YOUR ACCOUNT</h3></center>
                                        </div>
                                    </div>
                                </div>
                            </div>

                            
                        </div>
                        <!-- end row -->

                     
                    </div> <!-- container-fluid -->
                </div>
                <!-- End Page-content -->

                <footer class="footer">
                    <div class="container-fluid">
                        <div class="row">
                            <div class="col-sm-12">
                                © <script>document.write(new Date().getFullYear())</script> All right reserved
                            </div>
                        </div>
                    </div>
                </footer>
            </div>
            <!-- end main content-->

        </div>
        <!-- END layout-wrapper -->

        <!-- Right Sidebar -->
        <div class="right-bar">
            <div data-simplebar class="h-100">

                <div class="rightbar-title d-flex align-items-center px-3 py-4">
            
                    <h5 class="m-0 me-2">Settings</h5>

                    <a href="javascript:void(0);" class="right-bar-toggle ms-auto">
                        <i class="mdi mdi-close noti-icon"></i>
                    </a>
                </div>

                <!-- Settings -->
                <hr class="mt-0" />
                <h6 class="text-center mb-0">Choose Layouts</h6>

                <div class="p-4">
                    <div class="mb-2">
                        <img src="assets/images/layouts/layout-1.jpg" class="img-thumbnail" alt="">
                    </div>
                    <div class="form-check form-switch mb-3">
                        <input type="checkbox" class="form-check-input theme-choice" id="light-mode-switch" checked />
                        <label class="form-check-label" for="light-mode-switch">Light Mode</label>
                    </div>
    
                    <div class="mb-2">
                        <img src="assets/images/layouts/layout-2.jpg" class="img-thumbnail" alt="">
                    </div>
                    <div class="form-check form-switch mb-3">
                        <input type="checkbox" class="form-check-input theme-choice" id="dark-mode-switch" data-bsStyle="assets/css/bootstrap-dark.min.css" data-appStyle="assets/css/app-dark.min.css" />
                        <label class="form-check-label" for="dark-mode-switch">Dark Mode</label>
                    </div>
    
                    <div class="mb-2">
                        <img src="assets/images/layouts/layout-3.jpg" class="img-thumbnail" alt="">
                    </div>
                    <div class="form-check form-switch mb-5">
                        <input type="checkbox" class="form-check-input theme-choice" id="rtl-mode-switch" data-appStyle="assets/css/app-rtl.min.css" />
                        <label class="form-check-label" for="rtl-mode-switch">RTL Mode</label>
                    </div>

            
                </div>

            </div> <!-- end slimscroll-menu-->
        </div>
        <!-- /Right-bar -->

        <!-- Right bar overlay-->
        <div class="rightbar-overlay"></div> 
        
        <!-- JAVASCRIPT -->
        <script src="assets/libs/jquery/jquery.min.js"></script>
        <script src="assets/libs/bootstrap/js/bootstrap.bundle.min.js"></script>
        <script src="assets/libs/metismenu/metisMenu.min.js"></script>
        <script src="assets/libs/simplebar/simplebar.min.js"></script>
        <script src="assets/libs/node-waves/waves.min.js"></script>
        <script src="assets/libs/jquery-sparkline/jquery.sparkline.min.js"></script>

        <!--Morris Chart-->
        <script src="assets/libs/morris.js/morris.min.js"></script>
        <script src="assets/libs/raphael/raphael.min.js"></script>

        <script src="assets/js/pages/dashboard.init.js"></script>

        <!-- App js -->
        <script src="assets/js/app.js"></script>
    </body>


<!-- Mirrored from themesbrand.com/lexa/layouts/purple/layouts-horizontal.html by HTTrack Website Copier/3.x [XR&CO'2014], Sun, 13 Jun 2021 21:47:16 GMT -->
</html>