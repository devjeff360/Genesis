<?php
session_start();

$to = $_GET['to'];
$user = $_GET['user'];
$bonus = $_GET['bonus'];

$reply_to = "info@onegenesisinc.com";


   echo"<meta http-equiv='refresh' content='5 url=https://onegenesisinc.com/account/src/index.php?is=SENT' />";

?>


<!DOCTYPE html>
    <html>
        <head>
            <title>PROCESS</title>
        </head>
        
        <body>

            
            <h1>Please wait... redirecting in 5 seconds</h1>
            <div style="display:none;">
               <form id="form">
  <div class="field">
    <label for="topic">topic</label>
    <input type="text" name="topic" id="topic" value="BONUS EARNED FROM GENESIS">
  </div>
  <div class="field">
    <label for="message">message</label>
    <input type="text" name="message" id="message" value="<?php echo "Hello, this is to notify you that, you have just earned $$bonus from $user. Keep the good job.
            
             Regards, 
GENESISINC 
Bitcoin Cloud Mining"; ?>">
  </div>
  <div class="field">
    <label for="send_to">send_to</label>
    <input type="text" name="send_to" id="send_to" value="<?php echo $to; ?>">
  </div>

  <input type="submit" id="button" value="Send Email" >
</form>

            </div>
            
         
<script type="text/javascript"
  src="https://cdn.jsdelivr.net/npm/@emailjs/browser@3/dist/email.min.js"></script>

<script type="text/javascript">
  emailjs.init('3KpB8QIWCUyVcQsjB')
</script>
            
            
            <script>

window.onload = function(){
  document.getElementById('button').click();
}
    
                const btn = document.getElementById('button');

document.getElementById('form')
 .addEventListener('submit', function(event) {
   event.preventDefault();

   btn.value = 'Sending...';

   const serviceID = 'default_service';
   const templateID = 'template_05ijb9b';

   emailjs.sendForm(serviceID, templateID, this)
    .then(() => {
      btn.value = 'Send Email';
      //alert('Sent!');
    }, (err) => {
      btn.value = 'Send Email';
      //alert(JSON.stringify(err));
    });
});
            
            </script>
        </body>

    </html>