<?php session_start();

include_once("config.php");


 $access = $_SESSION['email'];

 if(!isset($access)){
  header("Location: https://onegenesisinc.com/account/index.php");
 }else{
     
     $getprofile = $con->query("SELECT * FROM reg_users WHERE email = '$access'") or die(mysqli_error($con));
     
     while($gp = $getprofile->fetch_assoc()){
        $firstname = $gp['firstname'];
        $lastname = $gp['lastname'];
        $email = $gp['email'];
        $phone = $gp['phone'];
        $password = $gp['password'];
     }
     
     $getbal = $con->query("SELECT * FROM bal WHERE email = '$access'") or die(mysqli_error($con));
     
     while($cl = $getbal->fetch_assoc()){
         $bal = $cl['balance'];
         $earn = $cl['earn'];
         $withdraw = $cl['withdraw'];
     }

     $totalinv = $con->query("SELECT SUM(amt) AS tinvest FROM invest WHERE email = '$access'") or die(mysqli_error($con));
     
        while($tin = $totalinv->fetch_assoc()){
            $tinvest = $tin['tinvest'];
        }
     
     

     $amt = $_GET['amt'];
     $date = $_GET['date'];
 
 }
?>

<!doctype html>
<html lang="en">

    
<!-- Mirrored from themesbrand.com/lexa/layouts/purple/layouts-horizontal.html by HTTrack Website Copier/3.x [XR&CO'2014], Sun, 13 Jun 2021 21:47:16 GMT -->
<head>

        <meta charset="utf-8" />
        <title>Client Dashboard</title>
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <meta content="Premium Multipurpose Admin & Dashboard Template" name="description" />
        <meta content="Themesbrand" name="author" />
        <!-- App favicon -->
        <link rel="shortcut icon" href="assets/images/favicon.ico"> 
        
        <!-- Bootstrap Css -->
        <link href="assets/css/bootstrap.min.css" id="bootstrap-style" rel="stylesheet" type="text/css" />
        <!-- Icons Css -->
        <link href="assets/css/icons.min.css" rel="stylesheet" type="text/css" />
        <!-- App Css-->
        <link href="assets/css/app.min.css" id="app-style" rel="stylesheet" type="text/css" />

    <script src="//code.jivosite.com/widget/0MPNPGglUA" async></script>

    <body data-topbar="light" data-layout="horizontal">

        <!-- Begin page -->
        <div id="layout-wrapper">

<?php include("sidebar.php"); ?>
            <!-- ============================================================== -->
            <!-- Start right Content here -->
            <!-- ============================================================== -->
            <div class="main-content">
<?php if($msg){
                    echo "<p class='alert alert-success'>$msg</p>";
                }else{
                    echo"";
                }  ?>
                <div class="page-content">
                    <div class="container-fluid">

                        <div class="row">


                              <div class="col-xl-12">
                       <h4>Send exactly <b>$<?php echo $amt; ?></b> worth of USDT ERC20<br /> to the address below.</h4>
                      <h4>Debit amount: $<?php echo $amt; ?></h4>
                      <h4>Date: <?php echo $date; ?></h4>
                      
                      <?php 
                    $getdata = $con->query("SELECT * FROM rewalls WHERE wname = 'USDT ERC20'") or die(mysqli_error($con));
                
                    while($gd = $getdata->fetch_assoc()){
                        $wname = $gd['wname'];
                        $wadd = $gd['wadd'];
                        $id = $gd['id'];
                    }
                ?>
                      
                      <label><b>Send USDT ERC20 to this address</b></label>
                  <input class="form-control" type="text" value="<?php echo $wadd; ?>" id="myInput">
                   
                      <br />
                      <input type="submit" value="Copy" class="btn btn-success" onclick="myFunction()" id="copy" />
                      
                      <br />
                      <p class="alert alert-info">Please Note: that it may sometimes take few minutes after payment for your balance to reflect due to blockchain verification</p>
                  </div>
                     </div>

                            
                        </div>
                        <!-- end row -->

                     
                    </div> <!-- container-fluid -->
                </div>
                <!-- End Page-content -->

                <footer class="footer">
                    <div class="container-fluid">
                        <div class="row">
                            <div class="col-sm-12">
                                © <script>document.write(new Date().getFullYear())</script> All right reserved
                            </div>
                        </div>
                    </div>
                </footer>
            </div>
            <!-- end main content-->

        </div>
        <!-- END layout-wrapper -->

        <!-- Right Sidebar -->
        <div class="right-bar">
            <div data-simplebar class="h-100">

                <div class="rightbar-title d-flex align-items-center px-3 py-4">
            
                    <h5 class="m-0 me-2">Settings</h5>

                    <a href="javascript:void(0);" class="right-bar-toggle ms-auto">
                        <i class="mdi mdi-close noti-icon"></i>
                    </a>
                </div>

                <!-- Settings -->
                <hr class="mt-0" />
                <h6 class="text-center mb-0">Choose Layouts</h6>

                <div class="p-4">
                    <div class="mb-2">
                        <img src="assets/images/layouts/layout-1.jpg" class="img-thumbnail" alt="">
                    </div>
                    <div class="form-check form-switch mb-3">
                        <input type="checkbox" class="form-check-input theme-choice" id="light-mode-switch" checked />
                        <label class="form-check-label" for="light-mode-switch">Light Mode</label>
                    </div>
    
                    <div class="mb-2">
                        <img src="assets/images/layouts/layout-2.jpg" class="img-thumbnail" alt="">
                    </div>
                    <div class="form-check form-switch mb-3">
                        <input type="checkbox" class="form-check-input theme-choice" id="dark-mode-switch" data-bsStyle="assets/css/bootstrap-dark.min.css" data-appStyle="assets/css/app-dark.min.css" />
                        <label class="form-check-label" for="dark-mode-switch">Dark Mode</label>
                    </div>
    
                    <div class="mb-2">
                        <img src="assets/images/layouts/layout-3.jpg" class="img-thumbnail" alt="">
                    </div>
                    <div class="form-check form-switch mb-5">
                        <input type="checkbox" class="form-check-input theme-choice" id="rtl-mode-switch" data-appStyle="assets/css/app-rtl.min.css" />
                        <label class="form-check-label" for="rtl-mode-switch">RTL Mode</label>
                    </div>

            
                </div>

            </div> <!-- end slimscroll-menu-->
        </div>
        <!-- /Right-bar -->
 <script>
function myFunction() {
  /* Get the text field */
  var copyText = document.getElementById("myInput");

  /* Select the text field */
  copyText.select();
  copyText.setSelectionRange(0, 99999); /*For mobile devices*/

  /* Copy the text inside the text field */
  document.execCommand("copy");

  /* Alert the copied text */
 // alert("Referral Link Copied: " + copyText.value);
    document.getElementById('copy').value = "Copied !";
}
</script>

        <!-- Right bar overlay-->
        <div class="rightbar-overlay"></div> 
        
        <!-- JAVASCRIPT -->
        <script src="assets/libs/jquery/jquery.min.js"></script>
        <script src="assets/libs/bootstrap/js/bootstrap.bundle.min.js"></script>
        <script src="assets/libs/metismenu/metisMenu.min.js"></script>
        <script src="assets/libs/simplebar/simplebar.min.js"></script>
        <script src="assets/libs/node-waves/waves.min.js"></script>
        <script src="assets/libs/jquery-sparkline/jquery.sparkline.min.js"></script>

        <!--Morris Chart-->
        <script src="assets/libs/morris.js/morris.min.js"></script>
        <script src="assets/libs/raphael/raphael.min.js"></script>

        <script src="assets/js/pages/dashboard.init.js"></script>

        <!-- App js -->
        <script src="assets/js/app.js"></script>
    </body>


<!-- Mirrored from themesbrand.com/lexa/layouts/purple/layouts-horizontal.html by HTTrack Website Copier/3.x [XR&CO'2014], Sun, 13 Jun 2021 21:47:16 GMT -->
</html>