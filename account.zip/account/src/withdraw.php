<?php session_start();

include_once("config.php");

 $access = $_SESSION['email'];

 if(!isset($access)){
  header("Location: https://onegenesisinc.com/account/index.php");
 }else{
     $getbal = $con->query("SELECT * FROM bal WHERE email = '$access'") or die(mysqli_error($con));
     
     while($cl = $getbal->fetch_assoc()){
         $bal = $cl['balance'];
         $withdraw = $cl['withdraw'];
     }
     
        $getinvest = $con->query("SELECT * FROM invest WHERE email = '$access' ORDER BY id DESC LIMIT 1") or die(mysqli_error($con));
     
        while($gin = $getinvest->fetch_assoc()){
            $package = $gin['pack'];
        }
     
     
      $getacc = $con->query("SELECT * FROM reg_users WHERE email = '$access'") or die(mysqli_error($con));
     
     while($rw = $getacc->fetch_assoc()){
         $acctype = $rw['acctype'];
         $det = $rw['det'];
         $user = $rw['user'];
     }
     
     
     if(isset($_POST['request'])){
         $em = $_POST['email'];
         $user = $_POST['user'];
         $atype = $_POST['acctype'];
         $dt = $_POST['det'];
         $amount = $_POST['amt'];
         $bl = $_POST['bal'];
         $with = $_POST['withdraw'];
         
         if($bal < $amount){
             
              echo "<script>alert('Insufficient balance');</script>";
         }else{
             
         
         
         $nbal = $bal - $amount;
         $nwith = $with + $amount;
         
         $rdate = date("d-m-Y");
         
         $getwith = $con->query("SELECT * FROM withdraw WHERE email = '$em' AND rdate = '$rdate'") or die(mysqli_error($con));
         
         if(mysqli_num_rows($getwith) > 2){
                echo "<script>alert('You can only make withdrawal three times in a day');</script>";
            }else{
             
         
         $update = $con->query("UPDATE bal SET balance = '$nbal', withdraw = '$nwith' WHERE email = '$em'") or die(mysqli_error($con));
         
         $insert = $con->query("INSERT INTO withdraw (email, user, amt, acctype, det, rdate, status) VALUES ('$em','$user','$amount','$atype','$dt','$rdate','PENDING')") or die(mysqli_error($con));
         
            if($update && $insert == TRUE){
                echo "<script>alert('Request sent, Your cash is on its way, Please dont send request again');</script>";
                echo"<meta http-equiv='refresh' content='0 url=https://onegenesisinc.com/account/src/gemail2.php?em=$em&amt=$amount' />";
            }else{
                echo "An error occure, please try again";
            }
         
     }
     }
     }
 }
?>


<!doctype html>
<html lang="en">

    
<!-- Mirrored from themesbrand.com/lexa/layouts/purple/layouts-horizontal.html by HTTrack Website Copier/3.x [XR&CO'2014], Sun, 13 Jun 2021 21:47:16 GMT -->
<head>

        <meta charset="utf-8" />
        <title>Client Dashboard</title>
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <meta content="Premium Multipurpose Admin & Dashboard Template" name="description" />
        <meta content="Themesbrand" name="author" />
        <!-- App favicon -->
        <link rel="shortcut icon" href="assets/images/favicon.ico"> 
        
        <!-- Bootstrap Css -->
        <link href="assets/css/bootstrap.min.css" id="bootstrap-style" rel="stylesheet" type="text/css" />
        <!-- Icons Css -->
        <link href="assets/css/icons.min.css" rel="stylesheet" type="text/css" />
        <!-- App Css-->
        <link href="assets/css/app.min.css" id="app-style" rel="stylesheet" type="text/css" />

    <script src="//code.jivosite.com/widget/0MPNPGglUA" async></script>

    <body data-topbar="light" data-layout="horizontal">

        <!-- Begin page -->
        <div id="layout-wrapper">

<?php include("sidebar.php"); ?>
            <!-- ============================================================== -->
            <!-- Start right Content here -->
            <!-- ============================================================== -->
            <div class="main-content">
<?php if($msg){
                    echo "<p class='alert alert-success'>$msg</p>";
                }else{
                    echo"";
                }  ?>
                <div class="page-content">
                    <div class="container-fluid">

                        <div class="row">


                              <div class="col-xl-6">
                        <div class="card shadow mb-4">
                  <div class="card-header py-3">
                    <h6 class="m-0 font-weight-bold text-primary">Request a withdrawal</h6>
                  </div>
                            <div class="card-body">
                    <form action="#" method="post" enctype="multipart/form-data" class="form-group">
                  <input name="email" type="text" class="form-control" value="<?php echo $access; ?>" style="display:none;" readonly><br>
                  <input name="user" type="text" class="form-control" value="<?php echo $user; ?>" style="display:none;" readonly>
                  
                    
                  
                  <input name="bal" type="text" class="form-control" value="<?php echo $bal; ?>" style="display:none;" readonly>
                  <input name="withdraw" type="text" class="form-control" value="<?php echo $withdraw; ?>" style="display:none;" readonly>
                      <label>Amount ($) <b style="color:red"><i class="fa fa-times"></i> 2,000 $</b> <b style="green"><i class="fa fa-check"></i> 2000</b></label>
                  <input name="amt" type="number" class="form-control" required placeholder="Amount ($) e.g (20000)"><br>
                        
                        <label>Wallet Type</label>
                     <select class="form-control" name="acctype" required>
                             <option value="">SELECT PAYMENT METHOD</option>
                            <option value="Bitcoin">Bitcoin</option>
                            <option value="ETH">ETH</option>
                            <option value="USDT TRC20">USDT TRC20</option>
                            <option value="USDT ERC20">USDT ERC20</option>
                            <option value="Tron">Tron</option>
                            <option value="Litecoin">Litecoin</option>
                            <option value="BNB">BNB</option>
                            <option value="Paypal" disabled>Paypal (Coming soon)</option>
                            <option value="Cashapp" disabled>Cashapp (Coming soon)</option>
                </select>
                        
                        <label>Wallet Address</label>
                        <input name="det" type="text" class="form-control" placeholder="Wallet address">
                    <button type="submit" name="request" class="btn btn-success btn-block">Request Withdrawal Now <i class="fas fa-wallet"></i></button>
                 
                  </form>
                   
                  </div>
                </div>     
                     </div>
                            
                            <div class="col-xl-6">
                                <h3>Withdrawal History</h3>
                                
                                         <div class="table-responsive">
                                 <table class="table table-bordered table-hover"  width="100%" cellspacing="0">
                        <thead>
                        <tr>
                          <th>Date</th>
                          <th>Amount (<img src="usd.png" />)</th>
                          <th>Wallet type</th>
                          <th>Status</th>
                        </tr>
                      </thead>
                          <tbody>
                          <?php $getinvest2 = $con->query("SELECT * FROM withdraw WHERE email = '$access' ORDER BY id DESC LIMIT 100") or die(mysqli_error($con));
     
        while($gin2 = $getinvest2->fetch_assoc()){
            $rd = $gin2['rdate'];
            $amount = $gin2['amt'];
            $act = $gin2['acctype'];
            $sts = $gin2['status'];
        
                              ?>
                              
                              <tr>
                                <td><?php echo $rd; ?></td>
                                <td><?php echo $amount; ?></td>
                                <td><?php echo $act; ?></td>
                                <td><?php echo $sts; ?></td>
                              </tr>
                              
                              <?php } ?>
                          </tbody>
                      <tfoot>
                     <tr>
                         <th>Date</th>
                          <th>Amount (<img src="usd.png" />)</th>
                          <th>Wallet type</th>
                          <th>Status</th>
                        </tr>
                  </tfoot>
                  
                      </table>
                                            
                                            
                             </div>
                               
                            
                            </div>

                            
                        </div>
                        <!-- end row -->

                     
                    </div> <!-- container-fluid -->
                </div>
                <!-- End Page-content -->

                <footer class="footer">
                    <div class="container-fluid">
                        <div class="row">
                            <div class="col-sm-12">
                                © <script>document.write(new Date().getFullYear())</script> All right reserved
                            </div>
                        </div>
                    </div>
                </footer>
            </div>
            <!-- end main content-->

        </div>
        <!-- END layout-wrapper -->

        <!-- Right Sidebar -->
        <div class="right-bar">
            <div data-simplebar class="h-100">

                <div class="rightbar-title d-flex align-items-center px-3 py-4">
            
                    <h5 class="m-0 me-2">Settings</h5>

                    <a href="javascript:void(0);" class="right-bar-toggle ms-auto">
                        <i class="mdi mdi-close noti-icon"></i>
                    </a>
                </div>

                <!-- Settings -->
                <hr class="mt-0" />
                <h6 class="text-center mb-0">Choose Layouts</h6>

                <div class="p-4">
                    <div class="mb-2">
                        <img src="assets/images/layouts/layout-1.jpg" class="img-thumbnail" alt="">
                    </div>
                    <div class="form-check form-switch mb-3">
                        <input type="checkbox" class="form-check-input theme-choice" id="light-mode-switch" checked />
                        <label class="form-check-label" for="light-mode-switch">Light Mode</label>
                    </div>
    
                    <div class="mb-2">
                        <img src="assets/images/layouts/layout-2.jpg" class="img-thumbnail" alt="">
                    </div>
                    <div class="form-check form-switch mb-3">
                        <input type="checkbox" class="form-check-input theme-choice" id="dark-mode-switch" data-bsStyle="assets/css/bootstrap-dark.min.css" data-appStyle="assets/css/app-dark.min.css" />
                        <label class="form-check-label" for="dark-mode-switch">Dark Mode</label>
                    </div>
    
                    <div class="mb-2">
                        <img src="assets/images/layouts/layout-3.jpg" class="img-thumbnail" alt="">
                    </div>
                    <div class="form-check form-switch mb-5">
                        <input type="checkbox" class="form-check-input theme-choice" id="rtl-mode-switch" data-appStyle="assets/css/app-rtl.min.css" />
                        <label class="form-check-label" for="rtl-mode-switch">RTL Mode</label>
                    </div>

            
                </div>

            </div> <!-- end slimscroll-menu-->
        </div>
        <!-- /Right-bar -->
 <script>
function myFunction() {
  /* Get the text field */
  var copyText = document.getElementById("myInput");

  /* Select the text field */
  copyText.select();
  copyText.setSelectionRange(0, 99999); /*For mobile devices*/

  /* Copy the text inside the text field */
  document.execCommand("copy");

  /* Alert the copied text */
 // alert("Referral Link Copied: " + copyText.value);
    document.getElementById('copy').value = "Copied !";
}
</script>

        <!-- Right bar overlay-->
        <div class="rightbar-overlay"></div> 
        
        <!-- JAVASCRIPT -->
        <script src="assets/libs/jquery/jquery.min.js"></script>
        <script src="assets/libs/bootstrap/js/bootstrap.bundle.min.js"></script>
        <script src="assets/libs/metismenu/metisMenu.min.js"></script>
        <script src="assets/libs/simplebar/simplebar.min.js"></script>
        <script src="assets/libs/node-waves/waves.min.js"></script>
        <script src="assets/libs/jquery-sparkline/jquery.sparkline.min.js"></script>

        <!--Morris Chart-->
        <script src="assets/libs/morris.js/morris.min.js"></script>
        <script src="assets/libs/raphael/raphael.min.js"></script>

        <script src="assets/js/pages/dashboard.init.js"></script>

        <!-- App js -->
        <script src="assets/js/app.js"></script>
    </body>


<!-- Mirrored from themesbrand.com/lexa/layouts/purple/layouts-horizontal.html by HTTrack Website Copier/3.x [XR&CO'2014], Sun, 13 Jun 2021 21:47:16 GMT -->
</html>