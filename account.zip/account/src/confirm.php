<?php session_start();

include_once("config.php");


 $access = $_SESSION['email'];

 if(!isset($access)){
  header("Location: https://onegenesisinc.com/account/index.php");
 }else{
     
     $getprofile = $con->query("SELECT * FROM reg_users WHERE email = '$access'") or die(mysqli_error($con));
     
     while($gp = $getprofile->fetch_assoc()){
        $firstname = $gp['firstname'];
        $lastname = $gp['lastname'];
        $email = $gp['email'];
        $phone = $gp['phone'];
        $password = $gp['password'];
     }
     
     
     $getbal = $con->query("SELECT * FROM bal WHERE email = '$access'") or die(mysqli_error($con));
     
     while($cl = $getbal->fetch_assoc()){
         $bal = $cl['balance'];
     }
     
     
     if(isset($_POST['invest'])){
         $email = mysqli_real_escape_string($con, $_POST['email']);
         $user = mysqli_real_escape_string($con, $_POST['user']);
         $pack = mysqli_real_escape_string($con, $_POST['pack']);
         $amt = mysqli_real_escape_string($con, $_POST['amt']);
         $min = mysqli_real_escape_string($con, $_POST['min']);
         $max = mysqli_real_escape_string($con, $_POST['max']);
         $percent = mysqli_real_escape_string($con, $_POST['percent']);
         $roi = mysqli_real_escape_string($con, $_POST['roi']);
         $dura = mysqli_real_escape_string($con, $_POST['dura']);
         $bal = mysqli_real_escape_string($con, $_POST['bal']);
         $rdate = mysqli_real_escape_string($con, $_POST['rdate']);
         $rtime = mysqli_real_escape_string($con, $_POST['rtime']);
         
         if($amt > $bal){
             echo"<script>alert('Low Balance');</script>";
             echo"<meta http-equiv='refresh' content='0 url=investment.php' />";
         }else{
              if($amt < $min || $amt > $max){
             echo"<script>alert('Amount is below the minimum or above the maximum');</script>";
                  echo"<meta http-equiv='refresh' content='0 url=investment.php' />";
         }else{
                  //getref
                  
                  $getref = $con->query("SELECT * FROM refs WHERE email = '$email' AND status = 'Not Redeemed'") or die(mysqli_error($con));
                  
                  while($gr = $getref->fetch_assoc()){
                      $upuser = $gr['refby'];
                  }
                  
                  $getrefbal = $con->query("SELECT * FROM bal WHERE user = '$upuser'") or die(mysqli_error($con));
                  
                  while($grb = $getrefbal->fetch_assoc()){
                      $upbal = $grb['balance'];
                      $upmail = $grb['email'];
                  }
                  
                  $bon = $amt / 100;
                  $bonus = $bon * 5;
                  
                  $newbal2 = $upbal + $bonus;
                  
                  
                  //end here
                  
               $newbal = $bal - $amt;
         
         $insert = $con->query("INSERT INTO invest (email, user, pack, amt, dura, roi, rdate, rtime, status) VALUES ('$email','$user','$pack','$amt','$dura','$roi','$rdate','$rtime','Active')") or die(mysqli_error($con));
         
         $update = $con->query("UPDATE bal SET balance = '$newbal' WHERE email = '$email'") or die (mysqli_error($con));
         $update2 = $con->query("UPDATE bal SET balance = '$newbal2' WHERE user = '$upuser'") or die (mysqli_error($con));
                  
         $update3 = $con->query("UPDATE refs SET status = 'Redeemed' WHERE email = '$email'") or die (mysqli_error($con));
           
               if($insert && $update == TRUE){
                   
             echo"<script>alert('Investment Placed');</script>";
         echo"<meta http-equiv='refresh' content='0 url=https://onegenesisinc.com/account/src/gemail.php?to=$email&user=$user&pack=$pack&amt=$amt&roi=$roi&rdate=$rdate&rtime=$rtime&bonus=$bonus&upmail=$upmail' />";
         }else{
             echo"<script>alert('An error occured');</script>";
         echo"<meta http-equiv='refresh' content='0 url=invest.php' />";
         }    
                   
                   
             
         }
         }
     }
     
            
 }
?>