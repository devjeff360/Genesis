
            <header id="page-topbar">
                <div class="navbar-header">
                    <div class="container-fluid">
                        <div class="float-start">
                            <!-- LOGO  -->
                            <div class="navbar-brand-box">
                                <a href="index.php" class="logo logo-dark">
                                    <span class="logo-sm">
                                        <img src="logo.png" alt="" height="70" style="width:140px; height:40px; margin-top:15px;">
                                    </span>
                                    <span class="logo-lg">
                                        <img src="logo.png" alt="" style="width:140px; height:40px; margin-top:15px;">
                                    </span>
                                </a>
    
                                <a href="index.php" class="logo logo-light">
                                    <span class="logo-sm">
                                        <img src="logo.png" alt="" style="width:70px; height:45px; margin-top:15px;">
                                    </span>
                                    <span class="logo-lg">
                                        <img src="logo.png" alt="" style="width:100px; height:75px; margin-top:15px;">
                                    </span>
                                </a>
                            </div>
    
                            <button type="button" class="btn btn-sm px-3 font-size-24 d-lg-none header-item waves-effect waves-light" data-bs-toggle="collapse" data-bs-target="#topnav-menu-content">
                                <i class="mdi mdi-menu"></i>
                            </button>
                        </div>
    
                        <div class="float-end">
    
                          

    
                            <div class="dropdown d-none d-lg-inline-block">
                                <button type="button" class="btn header-item noti-icon waves-effect" data-toggle="fullscreen">
                                    <i class="mdi mdi-fullscreen font-size-24"></i>
                                </button>
                            </div>
    
                            <div class="dropdown d-inline-block d-lg-none ms-2">
                                <button type="button" class="btn header-item noti-icon waves-effect" id="page-header-search-dropdown" data-bs-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                    <i class="mdi mdi-magnify"></i>
                                </button>
                                
                            </div>

                
    
                            <div class="dropdown d-inline-block ms-1">
                                <button type="button" class="btn header-item noti-icon waves-effect" id="page-header-notifications-dropdown"
                                    data-bs-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                    <i class="ti-bell"></i>
                                    <span class="badge bg-danger rounded-pill">0</span>
                                </button>
                                <div class="dropdown-menu dropdown-menu-lg dropdown-menu-end p-0"
                                    aria-labelledby="page-header-notifications-dropdown">
                                    <div class="p-3">
                                        <div class="row align-items-center">
                                            <div class="col">
                                                <h5 class="m-0"> Notifications (0) </h5>
                                            </div>
                                        </div>
                                    </div>
                                    <div data-simplebar style="max-height: 230px;">
                                        
    
                                        <a href="javascript:void(0);" class="text-reset notification-item">
                                            <div class="d-flex">
                                                <div class="flex-shrink-0 me-3">
                                                    <div class="avatar-xs">
                                                    <span class="avatar-title border-warning rounded-circle ">
                                                        <i class="mdi mdi-message"></i>
                                                    </span>
                                                </div>
                                                </div>
                                                 <div class="flex-grow-1">
                                                    <h6 class="mb-1">No New Notifications</h6>
                                                    <div class="text-muted">
                                                        <p class="mb-1">Notifications will be displayed here if any</p>
                                                    </div>
                                                </div>
                                            </div>
                                        </a>
    
                                      
                                    </div>
                                   
                                </div>
                            </div>
    
                            <div class="dropdown d-inline-block">
                                <button type="button" class="btn header-item waves-effect" id="page-header-user-dropdown"
                                    data-bs-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                    <img class="rounded-circle header-profile-user" src="assets/images/Sample_User_Icon.png"
                                        alt="Header Avatar">
                                </button>
                                <div class="dropdown-menu dropdown-menu-end">
                                    <!-- item-->
                                    <a class="dropdown-item" href="#"><i class="mdi mdi-account-circle font-size-17 text-muted align-middle me-1"></i> Profile</a>
                                    <a class="dropdown-item" href="#"><i class="mdi mdi-wallet font-size-17 text-muted align-middle me-1"></i> History</a>
                                    <div class="dropdown-divider"></div>
                                    <a class="dropdown-item text-danger" href="https://onegenesisinc.com/account/index.php"><i class="mdi mdi-power font-size-17 text-muted align-middle me-1 text-danger"></i> Logout</a>
                                </div>
                            </div>
    
    
                        </div>
                    </div>
                </div>

                <div class="top-navigation">
                    <div class="page-title-content">
                        <div class="container-fluid">
                            <!-- start page title -->
                            <div class="row">
                                <div class="col-sm-6">
                                    <div class="page-title-box">
                                        <h4>Dashboard</h4>
                                    </div>
                                </div>
                                <div class="col-sm-6">
                                    <div class="state-information d-none d-sm-block">
                                        <div class="state-graph float-end">
                                            <div id="header-chart-1"></div>
                                            <div class="info">Invested: <?php echo ucwords("$ $tinvest"); ?></div>
                                        </div>
                                        <div class="state-graph">
                                            <div id="header-chart-2"></div>
                                            <div class="info">Withdrawn: <?php echo ucwords("$ $withdraw"); ?></div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <!-- end page title -->
                        </div>
                    </div>

                    <div class="container-fluid">
                        <div class="topnav">
                            <nav class="navbar navbar-light navbar-expand-lg topnav-menu">

                                <div class="collapse navbar-collapse" id="topnav-menu-content">
                                    <ul class="navbar-nav">
                                        <li class="nav-item">
                                            <a class="nav-link" href="index.php">
                                                <i class="ti-dashboard"></i>Dashboard
                                            </a>
                                        </li>
                                        
                                        <li class="nav-item">
                                            <a class="nav-link dropdown-toggle arrow-none" href="profile.php" id="topnav-components" role="button"
                                                data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                                <i class="ti-support"></i>Profile
                                            </a>
                                        </li>


                                        <li class="nav-item">
                                            <a class="nav-link dropdown-toggle arrow-none" href="investment.php" id="topnav-email" role="button"
                                                data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                                <i class="ti-email"></i>Start Investment
                                            </a>
                                        </li>

                                        
                                        <li class="nav-item">
                                            <a class="nav-link dropdown-toggle arrow-none" href="wallet.php" id="topnav-forms" role="button"
                                                data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                                <i class="ti-receipt"></i>Funds Management
                                            </a> 
                                        </li>

                                        <li class="nav-item">
                                            <a class="nav-link dropdown-toggle arrow-none" href="alltrans.php" id="topnav-more" role="button"
                                                data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                                <i class="ti-menu-alt"></i>History
                                            </a>
                                        </li>

                                        <li class="nav-item">
                                            <a class="nav-link dropdown-toggle arrow-none" href="myrefs.php" id="topnav-charts" role="button"
                                                data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                                <i class="ti-pie-chart"></i>My Referrals
                                            </a>
                                        </li>
                                            
                                        <li class="nav-item">
                                            <a class="nav-link dropdown-toggle arrow-none" href="support.php" id="topnav-layout" role="button"
                                                data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                                <i class="ti-tablet"></i>Support
                                            </a>
                                        </li>
                                        
                                         <li class="nav-item">
                                         <div id="ytWidget"></div><script src="https://translate.yandex.net/website-widget/v1/widget.js?widgetId=ytWidget&pageLang=en&widgetTheme=dark&autoMode=false" type="text/javascript"></script>
                                         </li>
                                    </ul>
                                </div>
                            </nav>
                        </div>
                    </div>
                </div>

   
            </header>
    