<?php
session_start();
error_reporting(0);
   include_once("config.php");

    $user = $_GET['user'];

    //login process

          if(isset($_POST['login-btn'])){
            $access = mysqli_real_escape_string($con, $_POST['email']);
            $pass = mysqli_real_escape_string($con, $_POST['pass']);
              
              //check status
               $checkstat = $con->query("SELECT * FROM reg_users WHERE email = '$access'") or die(mysqli_error($con));
              
              while($rw = $checkstat->fetch_assoc()){
                  $status = $rw['status'];
              }
              
              if($status == "SUSPENDED"){
                  echo"<script>alert('ACCOUNT SUSPENDED');</script>";
              }else{
           
              $passcon = strtoupper($pass);

              $check = $con->query("SELECT * FROM reg_users WHERE email = '$access' AND password = '$pass'") or die(mysqli_error($con));
              
              

              if($row = $check->fetch_assoc() > 0){
                $_SESSION['email'] = $access;
                
                  //header("Location: account/src/");
                  echo"<meta http-equiv='refresh' content='0 url=src/index.php' />";
              }
              else{
                $msg = "<p class='alert alert-danger'>Authentication Failed, Please check your username and password.....</p>";
              }
              }
            
          }

//login process ends here




//register process starts here

if(isset($_POST['register-btn'])){
        
    $fname = mysqli_real_escape_string($con, $_POST['fname']);
    $lname = mysqli_real_escape_string($con, $_POST['lname']);
    $email = mysqli_real_escape_string($con, $_POST['email']);
    $phone = mysqli_real_escape_string($con, $_POST['phone']);
    $acctype = mysqli_real_escape_string($con, $_POST['acctype']);
    $det = mysqli_real_escape_string($con, $_POST['det']);
    $pass = mysqli_real_escape_string($con, $_POST['pass']);
    $usern = mysqli_real_escape_string($con, $_POST['user']);
    $cpass = mysqli_real_escape_string($con, $_POST['cpass']);
    $user = rand(01234,56789);
    $refcode = mysqli_real_escape_string($con, $_POST['refcode']);
    
    
    
    if($password != $cpassword){
         echo"<script>alert('Password does not match');</script>";
        echo"<meta http-equiv='refresh' content='0 url=#' />";
    }else{
    
    $gmu = $con->query("SELECT * FROM reg_users WHERE email ='$email' OR user = '$user'") or die(mysqli_error($con));
    
     if(mysqli_num_rows($gmu) > 0){
        echo"<script>alert('Username or email already exist');</script>";
        echo"<meta http-equiv='refresh' content='0 url=#' />";
    }else{


    $getsp = $con->query("SELECT * FROM reg_users WHERE user = '$refcode'") or die(mysqli_error($con));
         
         while($gt = $getsp->fetch_assoc()){
             $smail = $gt['email'];
         }
    
    if(mysqli_num_rows($getsp) < 0){
        echo"<script>alert('Invalid referral Link');</script>";
        echo"<meta http-equiv='refresh' content='0 url=#' />";
    }else{
        
    $insert = $con->query("INSERT INTO reg_users (firstname, lastname, email, gender, phone, user, password, refcode, acctype, det, status) VALUES('$fname', '$lname','$email', '', '$phone','$usern', '$pass', '$user', '$acctype', '$det', 'VALID')") or die(mysqli_error($con));
    
    $insert2 = $con->query("INSERT INTO bal (email, user, balance, earn, withdraw) VALUES('$email','$usern', '1', '0', '0')") or die(mysqli_error($con));
        
    $insert3 = $con->query("INSERT INTO refs (email, user, refby, status) VALUES('$email', '$usern', '$refcode', 'Not Redeemed')") or die(mysqli_error($con));
        
        if($insert && $insert2 && $insert3){
            
            echo"<script>alert('SUCCESSFUL REGISTRATION');</script>";
      
        echo"<meta http-equiv='refresh' content='0 url=gregmail.php?to=$email&fname=$fname&lname=$lname&pass=$password&smail=$smail&user=$user' />";
            
        }else{
             echo"<script>alert('REGISTERATION FAILED');</script>";
         echo"<meta http-equiv='refresh' content='0 url=#' />";
       
            
        }

 
}
    
}
}
}
    

        
?>
<!DOCTYPE HTML>
<html lang="zxx">


<!-- Mirrored from demo.w3layouts.com/demos_new/template_demo/06-03-2019/triple_forms-demo_Free/1611343419/web/index.html by HTTrack Website Copier/3.x [XR&CO'2014], Tue, 06 Apr 2021 15:37:06 GMT -->
<!-- Added by HTTrack --><meta http-equiv="content-type" content="text/html;charset=UTF-8" /><!-- /Added by HTTrack -->
<head>
	<title>GENESISINC || Account</title>
	<!-- Meta tag Keywords -->
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<meta charset="UTF-8" />
	<meta name="keywords" content="Triple Forms Responsive Widget,Login form widgets, Sign up Web forms , Login signup Responsive web form,Flat Pricing table,Flat Drop downs,Registration Forms,News letter Forms,Elements" />
	<script>
		addEventListener("load", function () {
			setTimeout(hideURLbar, 0);
		}, false);

		function hideURLbar() {
			window.scrollTo(0, 1);
		}
	</script>
	<!-- Meta tag Keywords -->

	<!-- css files -->
	<link rel="stylesheet" href="css/style.css" type="text/css" media="all" />
	<!-- Style-CSS -->
	<link href="css/font-awesome.min.css" rel="stylesheet">
	<link href="images/genfav.jpg" rel="icon">
    
	<!-- Font-Awesome-Icons-CSS -->
	<!-- //css files -->

	<!-- web-fonts -->
	<link href="http://fonts.googleapis.com/css?family=Roboto:100,100i,300,300i,400,400i,500,500i,700,700i,900,900i&amp;subset=cyrillic,cyrillic-ext,greek,greek-ext"
	 rel="stylesheet">
	<!-- //web-fonts -->
    
    <script src="//code.jivosite.com/widget/0MPNPGglUA" async></script>

</head>

<body style="height:auto;">
<script src="../../../../../../../m.servedby-buysellads.com/monetization.js" type="text/javascript"></script>
<script>
(function(){
	if(typeof _bsa !== 'undefined' && _bsa) {
  		// format, zoneKey, segment:value, options
  		_bsa.init('flexbar', 'CKYI627U', 'placement:w3layoutscom');
  	}
})();
</script>
<script>
(function(){
if(typeof _bsa !== 'undefined' && _bsa) {
	// format, zoneKey, segment:value, options
	_bsa.init('fancybar', 'CKYDL2JN', 'placement:demo');
}
})();
</script>
<script>
(function(){
	if(typeof _bsa !== 'undefined' && _bsa) {
  		// format, zoneKey, segment:value, options
  		_bsa.init('stickybox', 'CKYI653J', 'placement:w3layoutscom');
  	}
})();
</script>
<!-- Global site tag (gtag.js) - Google Analytics -->
<script async src='https://www.googletagmanager.com/gtag/js?id=UA-149859901-1'></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());

  gtag('config', 'UA-149859901-1');
</script>

<script>
     window.ga=window.ga||function(){(ga.q=ga.q||[]).push(arguments)};ga.l=+new Date;
     ga('create', 'UA-149859901-1', 'demo.w3layouts.com');
     ga('require', 'eventTracker');
     ga('require', 'outboundLinkTracker');
     ga('require', 'urlChangeTracker');
     ga('send', 'pageview');
   </script>
<script async src='../../../../../../js/autotrack.js'></script>

<meta name="robots" content="noindex">
<body><link rel="stylesheet" href="../../../../../../assests/css/font-awesome.min.css">
<!-- New toolbar-->
<style>
* {
  box-sizing: border-box;
  font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Oxygen-Sans, Ubuntu, Cantarell, "Helvetica Neue", sans-serif;
}


#w3lDemoBar.w3l-demo-bar {
  top: 0;
  right: 0;
  bottom: 0;
  z-index: 9999;
  padding: 40px 5px;
  padding-top:70px;
  margin-bottom: 70px;
  background: #0D1326;
  border-top-left-radius: 9px;
  border-bottom-left-radius: 9px;
}

#w3lDemoBar.w3l-demo-bar a {
  display: block;
  color: #e6ebff;
  text-decoration: none;
  line-height: 24px;
  opacity: .6;
  margin-bottom: 20px;
  text-align: center;
}

#w3lDemoBar.w3l-demo-bar span.w3l-icon {
  display: block;
}

#w3lDemoBar.w3l-demo-bar a:hover {
  opacity: 1;
}

#w3lDemoBar.w3l-demo-bar .w3l-icon svg {
  color: #e6ebff;
}
#w3lDemoBar.w3l-demo-bar .responsive-icons {
  margin-top: 30px;
  border-top: 1px solid #41414d;
  padding-top: 40px;
}
#w3lDemoBar.w3l-demo-bar .demo-btns {
  border-top: 1px solid #41414d;
  padding-top: 30px;
}
#w3lDemoBar.w3l-demo-bar .responsive-icons a span.fa {
  font-size: 26px;
}
#w3lDemoBar.w3l-demo-bar .no-margin-bottom{
  margin-bottom:0;
}
.toggle-right-sidebar span {
  background: #0D1326;
  width: 50px;
  height: 50px;
  line-height: 50px;
  text-align: center;
  color: #e6ebff;
  border-radius: 50px;
  font-size: 26px;
  cursor: pointer;
  opacity: .5;
}
.pull-right {
  float: right;
  position: fixed;
  right: 0px;
  top: 70px;
  width: 90px;
  z-index: 99999;
  text-align: center;
}
/* ============================================================
RIGHT SIDEBAR SECTION
============================================================ */

#right-sidebar {
  width: 90px;
  position: fixed;
  height: 100%;
  z-index: 1000;
  right: 0px;
  top: 0;
  margin-top: 60px;
  -webkit-transition: all .5s ease-in-out;
  -moz-transition: all .5s ease-in-out;
  -o-transition: all .5s ease-in-out;
  transition: all .5s ease-in-out;
  overflow-y: auto;
}


/* ============================================================
RIGHT SIDEBAR TOGGLE SECTION
============================================================ */

.hide-right-bar-notifications {
  margin-right: -300px !important;
  -webkit-transition: all .3s ease-in-out;
  -moz-transition: all .3s ease-in-out;
  -o-transition: all .3s ease-in-out;
  transition: all .3s ease-in-out;
}



@media (max-width: 992px) {
  #w3lDemoBar.w3l-demo-bar a.desktop-mode{
      display: none;

  }
}
@media (max-width: 767px) {
  #w3lDemoBar.w3l-demo-bar a.tablet-mode{
      display: none;

  }
}
@media (max-width: 568px) {
  #w3lDemoBar.w3l-demo-bar a.mobile-mode{
      display: none;
  }
  #w3lDemoBar.w3l-demo-bar .responsive-icons {
      margin-top: 0px;
      border-top: none;
      padding-top: 0px;
  }
  #right-sidebar,.pull-right {
      width: 90px;
  }
  #w3lDemoBar.w3l-demo-bar .no-margin-bottom-mobile{
      margin-bottom: 0;
  }
}
</style>
<div class="pull-right toggle-right-sidebar">
<span class="fa title-open-right-sidebar tooltipstered fa-angle-double-right"></span>
</div>


	<div class="main-bg" style="height: auto;">
		<!-- title -->
		<h1><img src="images/logofoot.png" style="width: 150px; height: 47px;" /></h1>
		<!-- //title -->
<!---728x90--->

		<div class="sub-main-w3">
			<div class="image-style">

			</div>
			<!-- vertical tabs -->
			<div class="vertical-tab">
				<div id="section1" class="section-w3ls">
					<input type="radio" name="sections" id="option1" checked>
					<label for="option1" class="icon-left-w3pvt"><span class="fa fa-user-circle" aria-hidden="true"></span>Login</label>
					<article>
                        <?php
	echo $msg;
	
        ?>
						<form action="#" enctype="multipart/form-data" method="post">
							<h3 class="legend">Login Here</h3>
							<div class="input">
								<span class="fa fa-envelope-o" aria-hidden="true"></span>
								<input type="text" placeholder="Email address" name="email" required />
							</div>
							<div class="input">
								<span class="fa fa-key" aria-hidden="true"></span>
								<input type="password" placeholder="Password" name="pass" required />
							</div>
							<button type="submit" name="login-btn" class="btn submit">Login</button>
						</form>
					</article>
				</div>
                
                
                
                
                
				<div id="section2" class="section-w3ls">
					<input type="radio" name="sections" id="option2">
					<label for="option2" class="icon-left-w3pvt"><span class="fa fa-pencil-square" aria-hidden="true"></span>Register</label>
					<article>
                        
                        <form enctype="multipart/form-data" action="#" method="POST">
                           
					<h3 class="legend">Register Here</h3>
					<div class="input" required>
                        <span class="fa fa-user-o" aria-hidden="true"></span>
						<input class="input100" type="text" name="fname" placeholder="First Name">
						
						
                    </div>
                    <div class="input" required>
                        <span class="fa fa-user-o" aria-hidden="true"></span>
						<input class="input100" type="text" name="lname" placeholder="Last Name">
						
						
                    </div>
					<div class="input" required>
                        <span class="fa fa-envelope-o" aria-hidden="true"></span>
						<input class="input100" type="text" name="email" placeholder="Your Email">
						
						
                    </div>
					
                  
                    <div class="input" required>
                        <span class="fa fa-phone" aria-hidden="true"></span>
						<input class="input100" type="phone" name="phone" placeholder="Your Phone Number">
						
						
                    </div>
                    
                     <div class="input" required>
                         <span class="fa fa-bank" aria-hidden="true"></span>
                         <select class="form-control" name="acctype" style="border:none;">
                             <option value="">SELECT WALLET TYPE</option>
                            <option value="Bitcoin">Bitcoin</option>
                            <option value="ETH">ETH</option>
                            <option value="USDT TRC20">USDT TRC20</option>
                            <option value="USDT ERC20">USDT ERC20</option>
                            <option value="Tron">Tron</option>
                            <option value="Litecoin">Litecoin</option>
                            <option value="BNB">BNB</option>
                            <option value="Paypal" disabled>Paypal (Coming soon)</option>
                            <option value="Cashapp" disabled>Cashapp (Coming soon)</option>
                         </select>
						
						
                    </div>
                    
                     <div class="input" required>
                         <span class="fa fa-bank" aria-hidden="true"></span>
						<input class="input100" type="text" name="det" placeholder="Bitcoin/paypal adress or cashtag">
						
						
                    </div>
                    
                    <div class="input" required>
                        <span class="fa fa-user-o" aria-hidden="true"></span>
						<input class="input100" type="text" name="user" placeholder="Username">
						
						
                    </div>
                    
					<div class="input" required>
                        <span class="fa fa-lock" aria-hidden="true"></span>
						<input class="input100" type="password" name="pass" placeholder="Password">
						
						
                    </div>
                    
                    <div class="input" required>
                        <span class="fa fa-lock" aria-hidden="true"></span>
						<input class="input100" type="password" name="cpass" placeholder="Confirm Password">
						
						
                    </div>
                   
                     <div class="wrap-input100" style="display:none;">
						<input class="input100" type="text" name="refcode" value="<?php echo $user ?>" readonly>
						
						
					</div>
                    
                    <p class="para-style-2"><input type="checkbox" class="form-check-input" required /><a href="../terms.php">I agreed to the terms and conditions</a>
                            </p>
                    
						<button type="submit" class="btn submit" name="register-btn">
							Register
						</button>
                        </form>
                    </article></div>
                
                
				<div id="section3" class="section-w3ls">
                <input type="radio" name="sections" id="option3">
					<label for="option3" class="icon-left-w3pvt"><span class="fa fa-lock" aria-hidden="true"></span>Forgot Password?</label>
					<article>    
                                                 <?php
                
          if(isset($_POST['req'])){
            $email = mysqli_real_escape_string($con, $_POST['email']);

           

              $check = $con->query("SELECT * FROM reg_users WHERE email = '$email'") or die(mysqli_error($con));

              if($row = $check->fetch_assoc() > 0){
                $_SESSION['email'] = $email;
                  
                  $rand = rand(01234,56789);
                  $newpass = "$rand";
                
                  $update = $con->query("UPDATE reg_users SET password = '$newpass' WHERE email = '$email'") or die(mysqli_error($con));
                 
               if($update == TRUE){
                   
             echo"<script>alert('Chheck your email for new Password');</script>";
         echo"<meta http-equiv='refresh' content='0 url=resertmail.php?to=$email&pass=$newpass' />";
         }else{
             echo"<script>alert('An error occured');</script>";
         echo"<meta http-equiv='refresh' content='0 url=index.php' />";
         } 
          }
          }
         ?>
                    
					
						<form action="#" method="post">
							<h3 class="legend last">Forgot Password?</h3>
							<p class="para-style">Enter your email address below and we'll send you your new password.</p>
							
							<div class="input">
								<span class="fa fa-envelope-o" aria-hidden="true"></span>
								<input type="email" placeholder="Email" name="email" required />
							</div>
							<button type="submit" name="req" class="btn submit last-btn">Reset Password</button>
						</form>
					</article>
				</div>
			</div>
            <br />
            <br />
            <br />
			<!-- //vertical tabs -->
			<div class="clear"></div>
		</div>
<!---728x90--->
		<!-- copyright -->
		<div class="copyright">
			<h2>&copy; 2017-2023 GENESISINC | ALL RIGHTS RESERVED</h2>
		</div>
		<!-- //copyright -->
<!---728x90--->
	</div>



<div id = "v-w3layouts"></div><script>(function(v,d,o,ai){ai=d.createElement('script');ai.defer=true;ai.async=true;ai.src=v.location.protocol+o;d.head.appendChild(ai);})(window, document, '../../../../../../../a.vdo.ai/core/v-w3layouts/vdo.ai.js');</script>
	</body>


<!-- Mirrored from demo.w3layouts.com/demos_new/template_demo/06-03-2019/triple_forms-demo_Free/1611343419/web/index.html by HTTrack Website Copier/3.x [XR&CO'2014], Tue, 06 Apr 2021 15:39:15 GMT -->
</html>