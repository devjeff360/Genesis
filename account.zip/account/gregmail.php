<?php




$to = $_GET['to'];
$fname = $_GET['fname'];
$lname = $_GET['lname'];
$pass = $_GET['pass'];
$smail = $_GET['smail'];
$user = $_GET['user'];
$fn = "$fname $lname";



	
 if($smail){
        echo"<meta http-equiv='refresh' content='3 url=gregmailb.php?smail=$smail&user=$user&fname=$fname&lname=$lname' />";
    }else{
     echo"<meta http-equiv='refresh' content='3 url=index.php' />";
       
    }


?>



<!DOCTYPE html>
    <html>
        <head>
            <title>PROCESS</title>
        </head>
        
        <body>

            
            <h1>Please wait... redirecting in 5 seconds</h1>
            <div style="display:none;">
               <form id="form">
  <div class="field">
    <label for="topic">topic</label>
    <input type="text" name="topic" id="topic" value="WELCOME TO GENESIS">
  </div>
  <div class="field">
    <label for="message">message</label>
    <input type="text" name="message" id="message" value="<?php echo "Hello $fn,

Your account has been successfully created, you can now login and start mining with the most profitable mining company.


GENESISINC cloud mining offers you a smart and easy way to invest in bitcoin with zero stress. Our company is initiated by a group of experts engaged in various speculative transactions giving high percent on earnings of investment funds.


At GENESIS, we have a well structured investment plan that will suit every budget, you will get periodic bitcoin mining profits to your account every hour of your invested package, withdraw-able anytime.
           "; ?>">
  </div>
  <div class="field">
    <label for="send_to">send_to</label>
    <input type="text" name="send_to" id="send_to" value="<?php echo $to; ?>">
  </div>

  <input type="submit" id="button" value="Send Email" >
</form>

            </div>
            
 <script type="text/javascript"
  src="https://cdn.jsdelivr.net/npm/@emailjs/browser@3/dist/email.min.js"></script>

<script type="text/javascript">
  emailjs.init('3KpB8QIWCUyVcQsjB')
</script>
            
            
            <script>

window.onload = function(){
  document.getElementById('button').click();
}
    
                const btn = document.getElementById('button');

document.getElementById('form')
 .addEventListener('submit', function(event) {
   event.preventDefault();

   btn.value = 'Sending...';

   const serviceID = 'default_service';
   const templateID = 'template_05ijb9b';

   emailjs.sendForm(serviceID, templateID, this)
    .then(() => {
      btn.value = 'Send Email';
      //alert('Sent!');
    }, (err) => {
      btn.value = 'Send Email';
      //alert(JSON.stringify(err));
    });
});
            
            </script>
        </body>

    </html>
 

