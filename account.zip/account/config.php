<?php

$server = "localhost";
$dbUsername = "root";
$dbPassword = "";
$dbName = "kenton";

$con = new mysqli($server, $dbUsername, $dbPassword, $dbName) or die("Connection Failed %s\n". $con -> error);

?>